<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CashAdvanceRequestItem extends Model
{
    protected $table = 'cash_advance_request_item';
    public $guarded = [];
}
