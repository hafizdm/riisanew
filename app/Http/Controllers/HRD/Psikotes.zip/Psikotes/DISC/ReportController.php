<?php

namespace App\Http\Controllers\HRD\Psikotes\DISC;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Candidate;
use App\ScoreDISC;
use DB;
use App\KategoriDISC;

class ReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['candidate'] = Candidate::all();
        return view('hrd/psikotes/DISC/report/index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $candidate  = Candidate::where('id', $id)->first();
        $getVal     = ScoreDISC::select(DB::raw('SUM(score_plus) as score_plus'),DB::raw('SUM(score_minus) as score_minus') )
                    ->where('id_candidate', $id)
                    ->first();
        
        $getData    = ScoreDISC::where('id_candidate', $id)->get();

        // $category   = ["D", "I", "S", "C", "*"];
        
        // $datas=[];
        // foreach($category as $k){
        //     foreach($kategori as $x){
        //         if($x->nama_kategori == $k){
        //             $datas[] = $x->id;
        //         }
        //     }
        // }

        $kategori = KategoriDISC::get();
        $data_plus = [];
        $data_minus = [];
        $data_change = [];
        $datas = [];
        foreach($kategori as $dt){
            foreach($getData as $p){
                $plus   = ScoreDISC::where('id_kategori_plus', $dt->id)->count();
                $minus  = ScoreDISC::where('id_kategori_minus', $dt->id)->count();
                $change = $plus - $minus;
                $star   = $plus + $minus;

                $datas[$dt->id] = $dt->id." ".$plus." ".$minus." ".$change." ";
            }
        }
        $data    = compact("candidate","getVal","data_plus", "data_minus","datas");
        return view('hrd/psikotes/DISC/report/detail')->with($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
