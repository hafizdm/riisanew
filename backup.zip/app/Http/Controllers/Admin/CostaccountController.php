<?php

namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;
use App\Costaccount;
use Carbon\Carbon;
use Illuminate\Http\Request;

class CostaccountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $data['cost_account'] = Costaccount::orderBy('created_at', 'desc')->get();
        return view('admin/costaccount/index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
         $data['cost_account'] = Costaccount::all();
        return view('admin/costaccount/create', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $ca= new Costaccount();
        
        $ca->nama=$request->get('nama');
        $ca->created_at = Carbon::now()->toDateTimeString();
        $ca->save();
        return redirect('/cost-account')->with('success', 'Data Cost Account berhasil ditambahkan');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $data['cost_account']= Costaccount::find($id);
        
        return view('admin/costaccount/edit')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $ca = Costaccount::find($id);
        $ca->nama=$request->get('nama');
        $ca->updated_at = Carbon::now()->toDateTimeString();
        $ca->save();
        

         return redirect('/cost-account')->with('success', 'Data Cost Account berhasil diupdate');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $ca = Costaccount::destroy($id);
        if($ca){
            return response()->json([
                'success'=> 'cost account berhasil dihapus'
            ]);
        }
        else{
            return response()->json([
                'failes'=> 'cost account gagal dihapus'
            ]);
        }
        return response($response);
    }
}
