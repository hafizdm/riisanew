@extends('templates.header')

@section('content')
<!-- Content Header (Page header) -->
<section class="content-header">
    <span class="fonts" style="font-size: large;">
     <b> List Request Barang (Pembelian dan Pengeluaran)</b>
    </span>
    <ol class="breadcrumb">
        <li><a href="{{url('')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><a href="{{url('listRequest')}}"> List Request Barang </a></li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <div class="box">
        <div class="box-body">
            @if(session()->get('success'))
            <div class="alert alert-success alert-dismissible fade in"> {{ session()->get('success') }}
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            </div>
            @endif
            <div class="table-responsive">
                <table id="data-table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th width="5%">No.</th>
                            <th>Nomor Payment</th>
                            <th>Jenis Pembelian</th>
                            <th>Cost Code</th>
                            <th>Nama Barang</th>
                            <th>Jumlah Pembelian(satuan)</th>
                            <th>Harga Satuan</th>
                            <th>Total Pembayaran</th>
                            <th>Lokasi Kebutuhan</th>
                            <th>Keterangan</th>
                            <th>Tanggal Request(Pembelian)</th>
                            <th>Keterangan(VP/PM)</th>
                            <!--<th>Keterangan(CEO)</th>-->
                            <!--<th>Disetujui Oleh</th>-->
                            <th>Status Pembelian</th>
                            <th>Tanggal Disetujui</th>
                            <th>Status Pengeluaran</th>
                            <th>Tanggal Pengeluaran</th>
                           
                        </tr>
                    </thead>
                    <tbody>
                      @foreach($request_barang as $k => $d)
                          <tr>
                              <td>{{$loop->iteration}}</td>
                              @if($d->no_payment != '')
                                <td>{{$d->no_payment}}</td>
                              @else
                                <td>-</td>
                              @endif
                              <td>{{$d->masterjenisbarang->nama}}</td>
                              <td>{{$d->masterKategori->kode_kategori}}/{{$d->masterKategori->nama_kategori}}</td>
                              <td>{{$d->nama_barang}}</td>
                              <td>{{$d->quantity}} {{$d->quantity_satuan}}</td>
                              <td>@rupiah($d->harga),00</td>
                              <td>@rupiah($d->total),00</td>
                              <td>{{$d->lokasiProyek->nama}}</td>
                              <td>{{$d->keterangan}}</td>
                              <td>{{$d->tanggal_pengajuan}}</td>      
                              <td>{{$d->komentar_vp}}</td>
                              <!--<td>{{$d->komentar_ceo}}</td>-->
                              
                              <!--{{-- Request --}}-->
                                <!--@if($d->status_pengajuan == 0 && $d->status_PO == 0 && $d->status_paid == 0)-->
                                <!--  <td></td>-->
                                <!--@elseif($d->status_pengajuan == 1 && $d->status_PO == 0 && $d->status_paid == 0)-->
                                <!--  @if($d->nama_proyek == 3)-->
                                <!--      <td>{{$d->updated_vp_by}}</td>-->
                                <!--  @else-->
                                <!--      <td>{{$d->updated_manager_by}}</td>-->
                                <!--  @endif-->
                               
                                  
                                <!--{{-- Purchased Order --}}-->
                                <!--@elseif($d->status_pengajuan == 1 && $d->status_PO == 1 && $d->status_paid == 0)-->
                                <!--  <td>{{$d->updated_co_po_by}}</td>-->
                                <!--@elseif($d->status_pengajuan == 1 && $d->status_PO == 2 && $d->status_paid == 0)-->
                                <!--    @if($d->nama_proyek == 3)-->
                                <!--        <td>{{$d->updated_vp_po_by}}</td>-->
                                <!--    @else-->
                                <!--        <td>{{$d->updated_pm_po_by}}</td>-->
                                <!--    @endif-->
                                
                                  
                                <!--{{-- Payment --}}-->
                                <!--@elseif($d->status_pengajuan == 1 && $d->status_PO == 2 && $d->status_paid == 1)-->
                                <!--  <td>{{$d->updated_co_pay_by}}</td>-->
                                <!--@elseif($d->status_pengajuan == 1 && $d->status_PO == 2 && $d->status_paid == 2)-->
                                <!--  <td>{{$d->updated_cfo_pay_by}}</td>-->
                                <!--@elseif($d->status_pengajuan == 1 && $d->status_PO == 2 && $d->status_paid == 3)-->
                                <!--  <td>{{$d->updated_ceo_pay_by}}</td>-->
                                <!--@else-->
                                <!--    <td></td>-->
                                <!--@endif-->
                            
                           <!--{{-- Status Pembelian--}}-->
                            @if($d->status_pengajuan == 4 || $d->status_PO == 4 || $d->status_paid == 4)
                                <td style="text-align: center"><span class="label label-danger"> DITOLAK</span></td>
                            @elseif($d->status_pengajuan == 1 && $d->status_PO== 2 && $d->status_paid == 5)
                                <td style="text-align: center"><span class="label label-success" style="background-color: rgb(0, 123, 255) !important"> DISETUJUI</span></td>
                            @else
                                    <td></td>
                            @endif

                            <!--{{-- Approval Date Pembelian --}}-->
                            <td>{{ date('d-m-Y', strtotime($d->updated_at)) }}</td>

                            <!--{{-- Status Pengeluaran --}}-->
                            @if($d->status_brg_keluar == 0)
                                <td><a href="{{url('request-barang-keluar')}}/{{$d->id}}"><span class="label label-danger">AJUKAN REQUEST</span></a></td>
                            @elseif($d->status_brg_keluar == 1)
                                <td style="text-align: center"><span class="label label-warning">PROSES</span></td>
                            @else
                                <td style="text-align: center"><span class="label label-success">DISETUJUI</span></td>
                            @endif

                          <!--{{-- Approval Date Barang Keluar --}}-->
                          @if($d->tanggal_pengeluaran == null || $d->tanggal_pengeluaran == '' )
                              <td></td>
                          @else
                              <td>{{ date('d-m-Y', strtotime($d->tanggal_pengeluaran)) }}</td>
                          @endif
                          </tr>
                          @endforeach
                      </tbody>
                    
                </table>
            </div>
            {{-- end of car data  --}}
        </div>
        <!-- /.box-body -->
        <div class="box-footer"></div>
        <!-- /.box-footer-->
    </div>
    <!-- /.box -->

</section>
<!-- /.content -->

@endsection
@push('script')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

<script>
  $(function(){
    var mainTable = $('#data-table').DataTable();
    var selectedRow;
  });
</script>
@endpush 


