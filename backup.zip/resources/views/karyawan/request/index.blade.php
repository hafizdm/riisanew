@extends('templates.header')

@section('content')
<!-- Content Header (Page header) -->
<section class="content-header">
    <span class="fonts header-style">
      <b>Form Request Pembelian Barang</b>
    </span>
    <ol class="breadcrumb">
      <li><a href="{{url('')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active"><a href="{{url('request')}}"> Form Request Pembelian Barang </a></li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
<!-- filter field -->

    <!-- end of filter field -->
    <!-- Default box -->
    <div class="box">
        <div class="box-body">
            @if(session()->get('success'))
            <div class="alert alert-success alert-dismissible fade in"> {{ session()->get('success') }}
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            </div>
            @elseif(session()->get('failed'))
            <div class="alert alert-danger alert-dismissible fade in"> 
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <h4><i class="icon fa fa-ban"></i> Pemberitahuan !</h4>
              {{ session()->get('failed') }}
            </div>
            @endif

            {{-- sub menu  --}}
            <div style="margin-bottom: 20px">
                <a href="{{url('request/create')}}" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Request Pembelian Barang </a>
            </div>
            {{-- end of sub menu  --}}

            {{-- table data of car  --}}
            <div class="table-responsive">
                <table id="data-table" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th width="5%">No.</th>
                            <th>Nomor Request</th>
                            <th>Jenis Pembelian</th>
                            <th>Cost Code</th>
                            <th>Nama Barang</th>
                            <th>Lokasi Kebutuhan</th>
                            <th>Jumlah Pembelian(satuan)</th>
                            <th>Estimasi Harga Satuan</th>
                            <th>Estimasi Total Pembayaran</th>
                            <th>Keterangan</th>
                            <th>Tanggal Request</th>
                            <th>Status Request</th>
                            <th>Terakhir diproses oleh</th>
                            <th>Aksi</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                      @foreach($request_barang as $k => $d)
                          <tr>
                              <td>{{$loop->iteration}}</td>
                              @if($d->no_request != null && $d->no_po == null && $d->no_payment == null)
                                <td>{{$d->no_request}}</td>
                              @elseif($d->no_request != null && $d->no_po != null && $d->no_payment == null)
                                <td>{{$d->no_po}}</td>
                              @elseif($d->no_request != null && $d->no_po != null && $d->no_payment != null)
                                <td>{{$d->no_payment}}</td>
                              @else
                                <td></td>
                              @endif
                              
                              <td>{{$d->masterjenisbarang->nama}}</td>
                              <td>{{$d->masterKategori->kode_kategori}}/{{$d->masterKategori->nama_kategori}}</td>
                              <td>{{$d->nama_barang}}</td>
                              <td>{{$d->lokasiProyek->nama}}</td>
                              <td>{{$d->quantity}} {{$d->quantity_satuan}}</td>
                              <td>@rupiah($d->harga),00</td>
                              <td>@rupiah($d->total),00 </td>
                              <td>{{$d->keterangan}}</td>
                              <td>{{$d->tanggal_pengajuan}}</td>
                              
                                @if($d->status_pengajuan == 0 || $d->status_pengajuan == 1 && $d->status_PO == 0)
                                  <td><span class="label label-warning"> PROSES REQUEST</span></td>
                                  
                                @elseif($d->status_pengajuan == 1 && $d->status_PO == 0 || $d->status_PO == 1 || $d->status_PO == 2 && $d->status_paid == 0)
                                  <td><span class="label label-success"> PURCHASE ORDER</span></td>
                                
                                @elseif($d->status_pengajuan == 1 && $d->status_PO == 2 && $d->status_paid == 0 || $d->status_paid == 1 || $d ->status_paid == 2 || $d->status_paid == 3)
                                  <td><span class="label label-danger"> UNPAID</span></td>
                                  
                                @elseif($d->status_pengajuan == 4 || $d->status_PO == 4 || $d->status_paid == 4)
                                  <td><span class="label label-danger"> DITOLAK</span></td>
                                @else
                                    <td></td>
                                @endif
                                
                            
                                <!--{{-- Request --}}-->
                                @if($d->status_pengajuan == 0 && $d->status_PO == 0 && $d->status_paid == 0)
                                  <td></td>
                                @elseif($d->status_pengajuan == 1 && $d->status_PO == 0 && $d->status_paid == 0)
                                  @if($d->nama_proyek == 3)
                                      <td>{{$d->updated_vp_by}}</td>
                                  @else
                                      <td>{{$d->updated_manager_by}}</td>
                                  @endif
                               
                                  
                                <!--{{-- Purchased Order --}}-->
                                @elseif($d->status_pengajuan == 1 && $d->status_PO == 1 && $d->status_paid == 0)
                                  <td>{{$d->updated_co_po_by}}</td>
                                @elseif($d->status_pengajuan == 1 && $d->status_PO == 2 && $d->status_paid == 0)
                                    @if($d->nama_proyek == 3)
                                        <td>{{$d->updated_vp_po_by}}</td>
                                    @else
                                        <td>{{$d->updated_pm_po_by}}</td>
                                    @endif
                                
                                  
                                <!--{{-- Payment --}}-->
                                @elseif($d->status_pengajuan == 1 && $d->status_PO == 2 && $d->status_paid == 1)
                                  <td>{{$d->updated_co_pay_by}}</td>
                                @elseif($d->status_pengajuan == 1 && $d->status_PO == 2 && $d->status_paid == 2)
                                  <td>{{$d->updated_cfo_pay_by}}</td>
                                @elseif($d->status_pengajuan == 1 && $d->status_PO == 2 && $d->status_paid == 3)
                                  <td>{{$d->updated_ceo_pay_by}}</td>
                                @else
                                    <td></td>
                                @endif
                                
                                <td><button class='btn btn-xs btn-danger delete' data-id="{{$d->id}}"><span class='glyphicon glyphicon-trash'></span></button></td>
                          </tr>
                          @endforeach
                      </tbody>
                    
                </table>
            </div>
            {{-- end of car data  --}}
        </div>
        <!-- /.box-body -->
        <div class="box-footer"></div>
        <!-- /.box-footer-->
    </div>
    <!-- /.box -->

</section>
<!-- /.content -->
<!-- modal konfirmasi -->

<div class="modal fade" id="modal-konfirmasi" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title" id="myModalLabel">Konfirmasi</h4>
            </div>
            <div class="modal-body" id="konfirmasi-body"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger" data-id="" data-loading-text="<i class='fa fa-circle-o-notch fa-spin'></i> Deleting..." id="confirm-delete">Delete</button>
            </div>
        </div>
    </div>
</div>
<!-- end of modal konfirmasi -->
@endsection
@push('script')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

<script>

$(function(){

   
   var mainTable = $('#data-table').DataTable();
   var selectedRow;

  $('#data-table').on('click', '.delete', function (e) {
    e.preventDefault();
    selectedRow = mainTable.row( $(this).parents('tr') );

    $("#modal-konfirmasi").modal('show');

    $("#modal-konfirmasi").find("#confirm-delete").data("id", $(this).data('id'));
    $("#konfirmasi-body").text("Hapus Request Pembelian?");
  });
  $('#btnFilter').click(function() {
      //alert('dumbass');
      $('#data-table').DataTable().ajax.reload();
    });

    $('#resetFilter').click(function() {
      $('#formFilter')[0].reset();
      $('#data-table').DataTable().ajax.reload();
    });

  $('#confirm-delete').click(function(){
      var deleteButton = $(this);
      var id           = deleteButton.data("id");

      deleteButton.button('loading');

      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax(
      {
        url: "requestpembelian/"+id,
        type: 'POST',
        dataType: "JSON",
        data: {
          // _method:"DELETE"
          // "id": id
        },
        success: function (response)
        {
          deleteButton.button('reset');

          selectedRow.remove().draw();

          $("#modal-konfirmasi").modal('hide');

          Swal.fire({
            title: response.success,
            // text: response.success,
            type: 'success',
            confirmButtonText: 'Close',
            confirmButtonColor: '#AAA',
            onClose: function(){
               
            }
          })
        },
        error: function(xhr) {
          console.log(xhr.responseText);
        }
      });
  });
});
</script>
@endpush 


