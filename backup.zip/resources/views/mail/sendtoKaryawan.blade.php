<h4>
    <span>Dear Bapak/Ibu {{$data['nama']}}</span>
</h4>

<br>
<span>Pengajuan barang anda pada tanggal {{$data['tanggal_pengajuan']}} telah <b>DISETUJUI</b></span>
<br>
<br>
<span>Untuk detail informasinya silahkan login pada sistem atau klik <a href="https://riisa.rapidinfrastruktur.com"></a> link </a> ini.</span>
<br>
<br>
<span>Terima Kasih</span>
<br>
<br>
<span>RII-SA Administration Team</span>

