<h4>
    <span>Dear Bapak/Ibu {{$data['nama']}}
</h4>
<br>
<span>Request Pengajuan Pengeluaran Barang anda pada tanggal {{$data['tgl_pengajuan_pengeluaran']}} telah <b style="color: red">DISETUJUI</b></span>
<br>
<br>
<span>Untuk informasi lebih detail, silahkan klik <a href="https://riisa.rapidinfrastruktur.com">link</a> ini atau login ke sistem</span>
<br>
<br>
<span>Terima Kasih</span>
<br>
<br>
<span>RII-SA Administration Team</span>
