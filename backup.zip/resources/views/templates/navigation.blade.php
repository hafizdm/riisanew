<?php
  use \App\Http\Controllers\navigation;
?>
@if(!Auth::user())
<!-- jika belum ada session login -->
<script type="text/javascript">
    window.location.replace("{{ route('login') }}");
</script>
@else
<!-- jika sudah login -->
<header class="main-header">
  <!-- Logo -->
  <a href="{{ url('') }}" class="logo">
    <!-- mini logo for sidebar mini 50x50 pixels -->
    <span class="logo-mini"><b>RII-SA</b></span>
    <!-- logo for regular state and mobile devices -->
    <span class="logo-lg"><b>RII-</b>SA</span>
  </a>
  <!-- Header Navbar: style can be found in header.less -->
  <nav class="navbar navbar-static-top">
    <!-- Sidebar toggle button-->
    <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </a>

    <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">
        <!-- User Account: style can be found in dropdown.less -->
        <li class="dropdown user user-menu">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <!--<img src="{{ asset('AdminLTE-2.3.11/dist/img/avatar.png') }}" class="user-image" alt="User Image">-->
            @if(Auth::user()->role_id == 1 || Auth::user()->role_id == 10 || Auth::user()->role_id == 11 || Auth::user()->role_id == 12)
            <img src="{{ asset('AdminLTE-2.3.11/dist/img/avatar.png') }}" class="user-image" alt="User Image">
          @else
          <?php 
            $foto = Auth::user()->user_login->foto;
          ?>
            @if($foto == null)
              <img src="{{ asset('AdminLTE-2.3.11/dist/img/avatar.png') }}" class="user-image" alt="User Image">
            @else
              <img src="{{ asset('uploads/Karyawan/')."/".$foto}}" class="user-image" alt="User Image">
            @endif
        @endif
        
            <span class="hidden-xs">{{\Auth::user()->name}}</span>
          </a>
          <ul class="dropdown-menu">
            
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <form method="post" action="{{ url('logout') }}" style="display: inline">
                    {{ csrf_field() }}
                    <button class="btn btn-default btn-flat" type="submit">Keluar</button>
                  </form>
                </div>
              </li>
            </ul>
        </li>
      </ul>
    </div>
  </nav>
</header>

<!-- =============================================== -->

<!-- Left side column. contains the sidebar -->
<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel" style="padding:15px 10px 75px 10px !important;">
      
      <div class="pull-left image">
        @if(Auth::user()->role_id == 1 || Auth::user()->role_id == 10 || Auth::user()->role_id == 11 || Auth::user()->role_id == 12)
            <img src="{{ asset('AdminLTE-2.3.11/dist/img/avatar.png') }}" class="img-circle" alt="User Image">
          @else
          <?php 
            $foto = Auth::user()->user_login->foto;
          ?>
            @if($foto == null)
              <img src="{{ asset('AdminLTE-2.3.11/dist/img/avatar.png') }}" class="img-circle" alt="User Image">
            @else
              <img src="{{ asset('uploads/Karyawan/')."/".$foto}}" class="img-circle" alt="User Image">
            @endif
        @endif
      </div>

        <div class="pull-left info">
          @if(Auth::user()->username == "admin" || Auth::user()->username == "finance" || Auth::user()->username == "asset.management" || Auth::user()->username == "HRD")
            <p>{{\Auth::user()->name}}</p>
          @else
            <p>{{\Auth::user()->name}}</p>
            <p style="font-size: 13px;"><i class="fa fa-user" aria-hidden="true"></i> &nbsp; {{Auth::user()->user_login->jabatan->jenis_jabatan}}</p>
            <p style="font-size: 13px;"><i class="fa fa-map-marker" aria-hidden="true"></i> &nbsp; {{Auth::user()->user_login->lokasi->nama}}</p>
          @endif
            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
    </div>
    {{-- @if(Auth::user()->role()->name == "Karyawan"){ --}}
    <!-- sidebar menu: : style can be found in sidebar.less -->

    @if(Auth::user()->role_id==1)
    <!--{{-- ROLE ADMIN --}}-->
    <ul class="sidebar-menu">
      <li class="header"><b>MENU NAVIGASI</b></li>
      <li class="treeview">
        <a href="{{ url('') }}">
          <i class="fa fa-dashboard"></i> <span>Dashboard</span>
        </a>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-database"></i> <span>Master Data</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">

          <li class="">
            <a href="{{ url('listVendor') }}">
              <i class="fa fa-tasks"></i> <span>Vendor</span>
            </a>
          </li>
          <li class="">
            <a href="{{ url('divisi') }}">
              <i class="fa fa-tasks"></i> <span>Divisi</span>
            </a>
          </li>
          <li class="">
            <a href="{{ url('jabatan') }}">
              <i class="fa fa-tasks"></i> <span>Jabatan</span>
            </a>
          </li>

          {{-- <li class="">
            <a href="{{ url('posisi-jabatan') }}">
              <i class="fa fa-tasks"></i> <span>Posisi-Jabatan</span>
            </a>
          </li> --}}

          <li class="">
            <a href="{{ url('kategoribarang') }}">
              <i class="fa fa-tasks"></i> <span>Cost Code</span>
            </a>
          </li>
          <li class="">
            <a href="{{ url('barang') }}">
              <i class="fa fa-tasks"></i> <span>Barang</span>
            </a>
          </li>
           
          <li class="">
            <a href="{{ url('proyek') }}">
              <i class="fa fa-tasks"></i> <span>Proyek</span>
            </a>
          </li>

          <!--<li class="">-->
          <!--  <a href="{{ url('karyawan') }}">-->
          <!--    <i class="fa fa-tasks"></i> <span>Karyawan</span>-->
          <!--  </a>-->
          <!--</li>-->
         
        </ul>
      </li>
        
        <li class="treeview">
            <a href="#">
              <i class="fa fa-database"></i> <span>Master Data Timesheet</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
              <li class="">
                <a href="{{ url('resource') }}">
                  <i class="fa fa-user-circle-o"></i> <span>Resource</span>
                </a>
              </li>
              <li class="">
                <a href="{{ url('cost-account') }}">
                  <i class="fa fa-book"></i> <span>Cost Account</span>
                </a>
              </li>
              <li class="">
                <a href="{{ url('general-work') }}">
                  <i class="fa fa-briefcase"></i> <span>Working Type</span>
                  </a>
              </li>
            </ul>
        </li>
             
      <li class="treeview">
      <a href="{{url('listPO')}}">
          <i class="fa fa-clock-o"></i>Upload Procurement
          <span class="pull-right-container">
            <span class="label label-warning pull-right"><?php echo navigation::countUploadPO()?></span>
          </span>
        </a>
      </li>

      <li class="treeview">
        <a href="{{url('list-procurement')}}">
            <i class="fa fa-list"></i>List Procurement
            
          </a>
        </li>

      {{-- <li class="treeview">
        <a href="#">
          <i class="fa fa-archive"></i> <span>Inventori</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">

          
          <li class="">
            <a href="{{ url('inventory') }}">
              <i class="fa fa-tasks"></i> <span>Asset</span>
            </a>
          </li>
          <li class="">
            <a href="{{ url('inventory-nonasset') }}">
              <i class="fa fa-tasks"></i> <span>Non Asset</span>
            </a>
          </li>
        
          <li class="">
            <a href="{{ url('inventory-jasa') }}">
              <i class="fa fa-tasks"></i> <span>Jasa</span>
            </a>
          </li>       
        </ul>
      </li> --}}
      </li>

      </li>
    </ul>
  
    @elseif(Auth::user()->role_id==2)
    <!--{{-- ROLE KARYAWAN --}}-->
      <ul class="sidebar-menu">
        <li class="header"><b> MENU NAVIGASI</b></li>
        <li class="treeview">
          <a href="{{ url('') }}">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-plus-circle"></i> <span>Pengajuan Request</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="">
              <a href="{{ url('request') }}">
                <i class="fa fa-edit"></i>Pembelian Barang
                <span class="pull-right-container">
                  <span class="label label-warning pull-right"><?php echo navigation::requestPembelian()?></span>
                </span>
              </a>
            </li>

            <li class="">
              <a href="{{ url('request-barang-keluar') }}">
                <i class="fa fa-edit"></i>Pengeluaran Barang
                <span class="pull-right-container">
                  <span class="label label-warning pull-right"><?php echo navigation::requestPengeluaran()?></span>
                </span>
              </a>
            </li>

          </ul>
        </li>

        <li class="treeview">
          <a href="{{ url('listRequest') }}">
             <i class="fa fa-list"></i><span>List Request</span>
          </a>
        </li>
        
        <!--Updated by cici-->
        <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i> <span>Human Capital</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="treeview">
              <a href="#">
                <i class="fa fa-address-card"></i>
                <span>Profil Saya</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('ubah-data-diri')}}/{{Auth::user()->username}}"><i class="fa fa-user"></i>Ubah Profil</a></li>
                <li><a href="{{url('pengalaman')}}"><i class="fa fa-briefcase" aria-hidden="true"></i>Pengalaman</a></li>
                <li><a href="{{url('pendidikan')}}"><i class="fa fa-university" aria-hidden="true"></i>Pendidikan</a></li>
                <li><a href="{{url('upload-file')}}"><i class="fa fa-paperclip "></i>Upload File Pendukung</a></li>
              </ul>
            </li>
            <li class="">
              <a href="{{url('time-sheet')}}">
              <i class="fa fa-clock-o"></i>Time Sheet
            </a>
          </li>
          <li class="treeview">
            <a href="{{ url('pengajuan-spd') }}">
              <i class="fa fa-file-text-o"></i><span>Form SPD</span>
            </a>
          </li>
          </ul>
        </li>

        <li class="treeview">
          <a href="{{ url('ganti-password') }}/{{Auth::user()->id}}">
            <i class="fa fa-lock"></i> <span>Ganti Password</span>
          </a>
        </li>
      </ul>

    @elseif(Auth::user()->role_id==3)
    <!--{{-- ROLE MANAGER --}}-->
      <ul class="sidebar-menu">
        <li class="header"><b>MENU NAVIGASI</b></li>
        <li class="treeview">
          <a href="{{ url('') }}">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="treeview">
          <a href="{{ url('approvalManager') }}">
            <i class="fa fa-check-square-o"></i>Approval Request Barang
            <span class="pull-right-container">
              <span class="label label-warning pull-right"><?php echo navigation::countRequestManager()?></span>
            </span>
          </a>
        </li>
        <li class="treeview">
          <a href="{{ url('po-pm') }}">
            <i class="fa fa-check-square-o"></i>Approval Purchase Order
            <span class="pull-right-container">
              <span class="label label-warning pull-right"><?php echo navigation::countPurchasePM()?></span>
            </span>
          </a>
        </li>
        
        <!--Updated by cici-->
        <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i> <span>Human Capital</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="treeview">
              <a href="#">
                <i class="fa fa-address-card"></i>
                <span>Profil Saya</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="{{url('ubah-data-diri')}}/{{Auth::user()->username}}"><i class="fa fa-user"></i>Ubah Profil</a></li>
                <li><a href="{{url('pengalaman')}}"><i class="fa fa-briefcase" aria-hidden="true"></i>Pengalaman</a></li>
                <li><a href="{{url('pendidikan')}}"><i class="fa fa-university" aria-hidden="true"></i>Pendidikan</a></li>
                <li><a href="{{url('upload-file')}}"><i class="fa fa-paperclip "></i>Upload File Pendukung</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="{{ url('pengajuan-spd') }}">
                <i class="fa fa-file-text-o"></i><span>Form SPD</span>
              </a>
            </li>
          </ul>
        </li>
        <li class="treeview">
          <a href="{{ url('ganti-password-manager') }}/{{Auth::user()->id}}">
            <i class="fa fa-lock"></i> <span>Ganti Password</span>
          </a>
        </li>
       
      </ul>

    @elseif(Auth::user()->role_id == 4)
      @if(Auth::user()->id_lead_timesheet == 3)
        <!--{{-- VP For Timesheet General/HO --}}-->
        <ul class="sidebar-menu">
          <li class="header"><b>MENU NAVIGASI</b></li>
          <li class="treeview">
            <a href="{{ url('') }}">
              <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            </a>
          </li>
          <li class="treeview">
            <a href="{{ url('approvalVP') }}">
              <i class="fa fa-check-square-o"></i>Approval Request Barang
              <span class="pull-right-container">
                <span class="label label-warning pull-right"><?php echo navigation::countRequestVP()?></span>
              </span>
            </a>
          </li>
          
         <li class="treeview">
            <a href="{{ url('po-vp') }}">
              <i class="fa fa-check-square-o"></i> Approval Purchase Order
              <span class="pull-right-container">
                <span class="label label-warning pull-right"><?php echo navigation::countPurchaseVP()?></span>
              </span>
            </a>
          </li>
          
          <li class="treeview">
            <a href="{{url('persentase-timesheet')}}">
              <i class="fa fa-file-pdf-o" aria-hidden="true"></i>Timesheet Management
            </a>
          </li>

          <li class="treeview">
            <a href="{{ url('ganti-password-vp') }}/{{Auth::user()->id}}">
              <i class="fa fa-lock"></i> <span>Ganti Password</span>
            </a>
          </li>
        </ul>
      
    @elseif(Auth::user()->id_lead_timesheet == 2)
      <!--{{-- VP For Timesheet Project --}}-->
        <ul class="sidebar-menu">
          <li class="header"><b>MENU NAVIGASI</b></li>
          <li class="treeview">
            <a href="{{ url('') }}">
              <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            </a>
          </li>
          <li class="treeview">
            <a href="{{ url('approvalVP') }}">
              <i class="fa fa-check-square-o"></i>Approval Request Barang
              <span class="pull-right-container">
                <span class="label label-warning pull-right"><?php echo navigation::countRequestVP()?></span>
              </span>
            </a>
          </li>
          <li class="treeview">
            <a href="{{ url('po-vp') }}">
              <i class="fa fa-check-square-o"></i> Approval Purchase Order
              <span class="pull-right-container">
                <span class="label label-warning pull-right"><?php echo navigation::countPurchaseVP()?></span>
              </span>
            </a>
          </li>
          <li class="treeview">
            <a href="{{url('timesheet-project')}}">
              <i class="fa fa-clock-o"></i>Timesheet Management
            </a>
          </li>
          <li class="treeview">
            <a href="{{ url('ganti-password-vp') }}/{{Auth::user()->id}}">
              <i class="fa fa-lock"></i> <span>Ganti Password</span>
            </a>
          </li>
        </ul>

      @elseif(Auth::user()->id_lead_timesheet == 1)
        <!--{{-- VP For Timesheet Proposal--}}-->
          <ul class="sidebar-menu">
            <li class="header"><b>MENU NAVIGASI</b></li>
            <li class="treeview">
              <a href="{{ url('') }}">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
              </a>
            </li>
            <li class="treeview">
              <a href="{{ url('approvalVP') }}">
                <i class="fa fa-check-square-o"></i>Approval Request Barang
                <span class="pull-right-container">
                  <span class="label label-warning pull-right"><?php echo navigation::countRequestVP()?></span>
                </span>
              </a>
            </li>
            <li class="treeview">
              <a href="{{ url('po-vp') }}">
                <i class="fa fa-check-square-o"></i> Approval Purchase Order
                <span class="pull-right-container">
                  <span class="label label-warning pull-right"><?php echo navigation::countPurchaseVP()?></span>
                </span>
              </a>
            </li>

            <!--<li class="treeview">-->
            <!--<a href="{{url('time-sheet-proposal')}}">-->
            <!--    <i class="fa fa-clock-o"></i>Time Sheet Proposal-->
            <!--  </a>-->
            <!--</li>-->
            
              <li class="treeview">
                  <a href="#">
                    <i class="fa fa-clock-o"></i>
                    <span>Timesheet Management</span>
                    <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                  </a>
                  <ul class="treeview-menu">
                    <li><a href="{{url('time-sheet-proposal')}}"><i class="fa fa-plus"></i>Proposal</a></li>
                    <li><a href="{{url('time-sheet-marketing')}}"><i class="fa fa-edit" aria-hidden="true"></i>Marketing</a></li>
                  </ul>
                </li>
        
        
            <li class="treeview">
              <a href="{{ url('ganti-password-vp') }}/{{Auth::user()->id}}">
                <i class="fa fa-lock"></i> <span>Ganti Password</span>
              </a>
            </li>
          </ul>
        @endif
    @elseif(Auth::user()->role_id==5)
    <!--{{-- Role CEO --}}-->
      <ul class="sidebar-menu">
        <li class="header"><b>MENU NAVIGASI</b></li>
        <li class="treeview">
          <a href="{{ url('') }}">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="treeview">
          <a href="{{ url('payment-ceo') }}">
            <i class="fa fa-check-square-o"></i>Approval Payment
            <span class="pull-right-container">
              <span class="label label-warning pull-right"><?php echo navigation::countPaymentCEO()?></span>
            </span>
          </a>
        </li>
        <li class="treeview">
          <a href="{{url('approval-timesheet-ceo')}}">
              <i class="fa fa-check-square-o"></i>Approval Time Sheet
            </a>
        </li>
          
        <li class="treeview">
          <a href="{{ url('ganti-password-ceo') }}/{{Auth::user()->id}}">
            <i class="fa fa-lock"></i> <span>Ganti Password</span>
          </a>
        </li>

      </ul>

    @elseif(Auth::user()->role_id==8)
    <!--{{-- Role CO --}}-->
      <ul class="sidebar-menu">
        <li class="header"><b>MENU NAVIGASI</b></li>
        <li class="treeview">
          <a href="{{ url('') }}">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="treeview">
          <a href="{{ url('po') }}">
            <i class="fa fa-check-square-o"></i> Approval Purchase Order
              <span class="pull-right-container">
                <span class="label label-warning pull-right"><?php echo navigation::countPurchaseCO()?></span>
              </span>
          </a>
        </li>

        <li class="treeview">
          <a href="{{ url('payment-co') }}">
            <i class="fa fa-check-square-o"></i>Approval Payment
            <span class="pull-right-container">
              <span class="label label-warning pull-right"><?php echo navigation::countPaymentCO()?></span>
            </span>
          </a>
        </li>
        <li class="treeview">
          <a href="{{ url('ganti-password-co') }}/{{Auth::user()->id}}">
            <i class="fa fa-lock"></i> <span>Ganti Password</span>
          </a>
        </li>
      </ul>
      

    @elseif(Auth::user()->role_id == 9)
    <!--{{-- Role CFO --}}-->
      <ul class="sidebar-menu">
        <li class="header"><b>MENU NAVIGASI</b></li>
        <li class="treeview">
          <a href="{{ url('') }}">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        
        <li class="treeview">
          <a href="{{ url('payment-cfo') }}">
            <i class="fa fa-check-square-o"></i>Approval Payment
            <span class="pull-right-container">
              <span class="label label-warning pull-right"><?php echo navigation::countPaymentCFO()?></span>
            </span>
          </a>
        </li>
        <li class="treeview">
          <a href="{{ url('ganti-password-cfo') }}/{{Auth::user()->id}}">
            <i class="fa fa-lock"></i> <span>Ganti Password</span>
          </a>
        </li>

      </ul>

      @elseif(Auth::user()->role_id == 10)
      <!--{{-- Role Finance --}}-->
        <ul class="sidebar-menu">
          <li class="header"><b>MENU NAVIGASI</b></li>
          <li class="treeview">
            <a href="{{ url('') }}">
              <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            </a>
          </li>
          <li class="treeview">
            <a href="{{url('list-invoice')}}">
                <i class="fa fa-check-square-o"></i>Upload Invoice
                <span class="pull-right-container">
                  <span class="label label-warning pull-right"><?php echo navigation::countListInvoice()?></span>
                </span>
              </a>
          </li>

          <li class="treeview">
            <a href="{{url('ubah-status-paid')}}">
                <i class="fa fa-check-square-o"></i> Ubah Status Pembayaran
                <span class="pull-right-container">
                  <span class="label label-warning pull-right"><?php echo navigation::countListPayment()?></span>
                </span>
              </a>
          </li>
          <li class="treeview">
            <a href="{{ url('ganti-password-finance') }}/{{Auth::user()->id}}">
              <i class="fa fa-lock"></i> <span>Ganti Password</span>
            </a>
          </li>

        </ul>

        @elseif(Auth::user()->role_id == 11)
        <!--{{-- Role Asset Management --}}-->
          <ul class="sidebar-menu">
            <li class="header"><b>MENU NAVIGASI</b></li>
            <li class="treeview">
              <a href="{{ url('') }}">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
              </a>
            </li>
            
            {{-- <li class="treeview">
              <a href="#">
                <i class="fa fa-archive"></i> <span>Asset Management</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li class="">
                  <a href="{{ url('list-approval-barang-keluar') }}">
                    <i class="fa fa-check-square-o"></i> <span>Approval Barang Keluar</span>
                  </a>
                </li>
              </ul>
            </li> --}}

            <li class="treeview">
              <a href="{{url('list-approval-barang-keluar')}}">
                  <i class="fa fa-check-square-o"></i>Approval Barang Keluar
                  <span class="pull-right-container">
                    <span class="label label-warning pull-right"><?php echo navigation::countBarangKeluar()?></span>
                  </span>
                </a>
            </li>
            <li class="treeview">
              <a href="{{ url('ganti-password-assetmanagement') }}/{{Auth::user()->id}}">
                <i class="fa fa-lock"></i> <span>Ganti Password</span>
              </a>
            </li>
  
          </ul>
          
          @else
          <!--Role HR-->
            <ul class="sidebar-menu">
              <li class="header"><b>MENU NAVIGASI</b></li>
              <li class="treeview">
                <a href="{{ url('') }}">
                  <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
              </li>
              <li class="treeview">
                <a href="{{ url('karyawan') }}">
                  <i class="fa fa-edit"></i> <span>Data Karyawan</span>
                </a>
              </li>
              <li class="treeview">
                <a href="{{ url('history-spd') }}">
                  <i class="fa fa-file"></i> <span>History SPD</span>
                </a>
              </li>

            </ul>
      
    @endif

  </section>
  <!-- /.sidebar -->
</aside>
@endif 