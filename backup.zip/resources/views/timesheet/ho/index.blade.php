@extends('templates.header')

@section('content')
<section class="content-header">
    <span class="fonts" style="font-size:20px">
    <b>
        Time Sheet Management 
    </b>
    </span>
    <ol class="breadcrumb">
    <li><a href="{{url('')}}"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active"><a href="#">Detail Time Sheet</a></li>
    </ol>
</section>

<section class="content">
    <div class="box">
        <div class="box-body">
            @if(session()->get('success'))
                <div class="alert alert-success alert-dismissible fade in"> {{ session()->get('success') }}
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                </div>
            @elseif(session()->get('failed'))
                <div class="alert alert-danger alert-dismissible fade in"> 
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <h4><i class="icon fa fa-ban"></i> Pemberitahuan !</h4>
                {{ session()->get('failed') }}
                </div>
            @endif
            {{-- table data of car  --}}
            <div class="col-md-12">
                <div class="nav-tabs-custom">
                  <ul class="nav nav-tabs">
                    <li class="active"><a href="#approvals" data-toggle="tab"><i class="fa fa-check-square-o" aria-hidden="true"></i> &nbsp; Approval Time Sheet</a></li>
                    <li><a href="#total_man_hours" data-toggle="tab"><i class="fa fa-bar-chart"></i>&nbsp; Report Timesheet</a></li>
                  </ul>
                  <div class="tab-content">
                    <div class="active tab-pane" id="approvals">
                        <div class="table-responsive">
                            <table id="data-tables" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th style="width: 50px;"><center><input type="checkbox" id="selectAllApprove" name="selectAllApprove"></center><button class="btn btn-success btn-xs" id="btnSelectAll" name="btnSelectAll"><span>Approve All</span></button></th>
                                        <th width="5%">No.</th>
                                        <th>Tanggal Kerja</th>
                                        <th>Nama</th>
                                        <th>Divisi</th>
                                        <th>Jam Mulai</th>
                                        <th>Jam Selesai</th>
                                        <th>Deskripsi Pekerjaan</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                  @foreach($timesheet as $k => $d)
                                      <tr>
                                          <td><center><input type="checkbox" name="deleteAll[]" onclick="partialSelected()" class="bulkSelectAll" id="bulkSelectName" value="{{$d->id}}"></center></td>
                                            <td>{{$loop->iteration}}</td>
                                            @if((date('l', strtotime($d->tanggal_kerja))) == "Monday")
                                                <td>Senin, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td>
                                            @elseif((date('l', strtotime($d->tanggal_kerja))) == "Tuesday")
                                                <td>Selasa, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td>
                                            @elseif((date('l', strtotime($d->tanggal_kerja))) == "Wednesday")
                                                <td>Rabu, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td>
                                            @elseif((date('l', strtotime($d->tanggal_kerja))) == "Thursday")
                                                <td>Kamis, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td>
                                            @elseif((date('l', strtotime($d->tanggal_kerja))) == "Friday")
                                                <td>Jumat, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td>
                                            @elseif((date('l', strtotime($d->tanggal_kerja))) == "Saturday")
                                                <td>Sabtu, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td> 
                                            @elseif((date('l', strtotime($d->tanggal_kerja))) == "Sunday")
                                                <td>Minggu, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td>      
                                            @endif

                                            <td>{{$d->getNama->nama}}</td>
                                            <td>{{$d->getDiv->nama}}</td>
                                            <td>{{ date('H:i', strtotime($d->start_time)) }}</td>
                                            <td>{{ date('H:i', strtotime($d->end_time)) }}</td>
                                            <td>{{$d->workingType->nama}}
                                                <br>
                                                <b>Detail:</b>
                                                <br>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_ho)) !!}
                                            </td>
                                            
                                            @if($d->status == 0)
                                                <td><span class="label label-danger">Butuh Approval</span></td>
                                            @else 
                                                <td><span class="label label-danger">Disetujui</span></td>
                                            @endif

                                            <!--<td>-->
                                            <!--<a href="{{route('edit-status-timesheet-ho',$d->id)}}" class="btn btn-default btn-xs" style="color: dodgerblue;"><i class="fa fa-edit"></i>Ubah Status</a>-->
                                            <!--</td>-->
                                            <td>
                                                <center>
                                                    <form name="formdata" method="post" action="{{route('update-status-timesheet-ho', $d->id)}}">
                                                        @method('PATCH') 
                                                        @csrf
                                                        <input type="hidden" value="1" name="status" id="status">
                                                        <button type="submit" class="btn btn-default btn-xs" style="color: dodgerblue;"><i class="fa fa-check" aria-hidden="true"></i> &nbsp; Approve</button>
                                                    </form>
                                                    {{-- <a href="#" class="btn btn-default btn-xs" style="color: dodgerblue;"><i class="fa fa-times" aria-hidden="true"></i></a> --}}
                                                
                                        <form name="formdata" method="post" action="{{route('update-status-timesheet-ho', $d->id)}}">
                                        @method('PATCH') 
                                        @csrf
                                        <input type="hidden" value="2" name="status" id="status">
                                                        <button type="submit" class="btn btn-default btn-xs" style="color: red;">&nbsp;<i class="fa fa-times" aria-hidden="true"></i>&nbsp; Reject</button>
                                        </form>
                                         </center>
                                            
                                            </td>

                                      </tr>
                                      @endforeach
                                  </tbody>
                            </table>
                            </div>
                    </div>

                    <div class="tab-pane" id="total_man_hours">
                        <div class="table-responsive">
                            <table id="data-tables2" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th width="5%">No.</th>
                                        <th>NIK</th>
                                        <th>Nama</th>
                                        <th>Penempatan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  @foreach($data_karyawan as $d)
                                      <tr>
                                            <td>{{$loop->iteration}}</td>
                                            <td>{{$d->nik}}</td>
                                            <td>{{$d->nama}}</td>
                                            
                                            <td>
                                            @if($d->lokasi_id == '' || $d->lokasi_id == NULL)
                                           <span></span>
                                            @else
                                            <span>{{$d->lokasi->nama}}</span>
                                            @endif
                                            </td>
                                            
                                            <td>
                                            <a href="{{url('all-timesheet')}}/{{$d->nik}}" class="btn btn-default btn-xs" style="color: dodgerblue;"><i class="fa fa-eye"></i>&nbsp; Detail</a>
                                            </td>

                                      </tr>
                                      @endforeach
                                  </tbody>
                            </table>
                            </div>
                    </div>

</section>

@endsection
@push('script')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

<script>
$(function(){
  var data1 = $("#data-tables").DataTable();
  var data2 = $("#data-tables2").DataTable();
});


// Approval All
$('#selectAllApprove').on('click', function(){
    ($('#selectAllApprove').is(':checked') == true) ? selectAll() : deselectAll();
});

function selectAll()
{
    var id = [];
    var project_id = [];
    var resource_id = [];
    // var ddlViewBy = document.getElementById('status_approved');
    // var value = ddlViewBy.options[ddlViewBy.selectedIndex].value;
    
    $('.bulkSelectAll').prop("checked", true);
    $('.bulkSelectAll:checked').each(function(){
                id.push($(this).val());
                // var idproj = document.getElementById("project-id");
                // project_id.push(idproj.innerText);
                // var idres = document.getElementById("resource-id");
                // resource_id.push(idres.innerText);

                // id.push({'id': $(this).val(), 'project_id': idproj.innerText, 'resource_id': idres.innerText});
            });
}

function deselectAll()
{
    $('.bulkSelectAll').prop("checked", false)
}

// partial selected
function partialSelected()
{
  if($('#selectAllApprove').is(':checked'))
        {
            $('#selectAllApprove').prop("checked", false);
        }
            
    var id = [];
    var project_id = [];
    var resource_id = [];

    // var ddlViewBy = document.getElementById('status_approved');
    // var value = ddlViewBy.options[ddlViewBy.selectedIndex].value;
    $('.bulkSelectAll:checked').each(function(){
                id.push($(this).val());
                // var idproj = document.getElementById("project-id");
                // project_id.push(idproj.innerText);
                // var idres = document.getElementById("resource-id");
                // resource_id.push(idres.innerText);

                // id.push({'id': $(this).val(), 'project_id': idproj.innerText, 'resource_id': idres.innerText});
            });
}

function myFunction(event) {
    dt = event.options[event.selectedIndex].value;
    console.log(event.options[event.selectedIndex].value);
}

// var globalVal;
// $( "#status_approved" ).change(function() {
//      globalVal = $( "#status_approved option:selected" ).val();
// });

$('#btnSelectAll').on('click',function (e) {
    e.preventDefault();
    $("#modal-konfirmasi").modal('show');
    // bulk edit menampung id kedalam array
    var id = [];
    var project_id = [];
    var resource_id = [];
    // var ddlViewBy = document.getElementById('status_approved');
    // var value = ddlViewBy.options[ddlViewBy.selectedIndex].value;

    var mydataTable = $('#data-tables').DataTable();
    console.log(mydataTable.rows);

    // document.getElementById('status_approved').addEventListener('change', function() {
    //         console.log('You selected: ', this.value);  
    //     });
    // console.log(myFunction(event));
    console.log(dt);
    console.log("id>>>", id);
    $('.bulkSelectAll:checked').each(function(){
                id.push($(this).val());
                // var idproj = document.getElementById("project-id");
                // project_id.push(idproj.innerText);
                // var idres = document.getElementById("resource-id");
                // resource_id.push(idres.innerText);

                // id.push({'id': $(this).val(), 'project_id': idproj.innerText, 'resource_id': idres.innerText});
            });

    console.log(id);

    $("#modal-konfirmasi").find("#confirm-delete").data("id", id.id);


    $('#confirm-delete').click(function(){
      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax(
      {
        url: "{{ url('approve-ho') }}",
        type: 'POST',
        dataType: "JSON",
        data: {
          "id": id,
          "status": dt,
        //   "project_id" : project_id
        },
        success: function (response)
        {
          $("#modal-konfirmasi").modal('hide');
          Swal.fire({
            title: response.message,
            type: 'success',
            confirmButtonText: 'Close',
            confirmButtonColor: '#AAA',
            onClose: function(){
            }
          })
            console.log("project_id>>>>", response);

            $('#data-tables').DataTable().destroy();
            location.reload();
        },
        error: function(xhr) {
          console.log(xhr.responseText);
        }
      }); // end of ajax
    });
  });
</script>
@endpush


