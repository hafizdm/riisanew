<?php
use Carbon\Carbon as Carbon;
use App\Resource;
use App\TimeSheetUser;
use Illuminate\Support\Facades\DB;
?>

@extends('templates.header')
@section('content')
<section class="content"> 
<div class="row">
        <div class="col-xs-12 col-xl-8 col-lg-8">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title fonts"><b>Time Sheet Management</b></h3>
            </div>
            <br>
            <div class="box-body">
              <div id="notif" ></div>

              {{-- <div class="row">
                <div class="col-xs-12 col-xl-10 col-lg-10">
                    <form role="form" name="formdata" method="post" enctype="multipart/form-data" action="{{url("time-sheet/store")}}">
                    @csrf
                    <input type="hidden" id="divisi_id" name="divisi_id" value="{{$karyawan->divisi_id}}">
                    <div class="form-group">
                        <label for="jenis_barang">Cost Account</label>
                        <select name="cost_account_id" type="text" class="form-control select2" id="cost_account_id"  style="width: 100%;" onchange="showfield(this.options[this.selectedIndex].value)" required>
                            <option selected disabled>-- Pilih Cost Account --</option>
                            @foreach($cost_account as $ca)
                                <option value="{{ $ca->id }}">{{ $ca->nama }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div id="div1"></div>

                    <div class="bootstrap-timepicker">
                    <div class="form-group">
                        <label>Jam Mulai</label>
                        <div class="input-group">
                          <input type="text" class="form-control timepicker" id="start_time" name="start_time">
                          <div class="input-group-addon">
                            <i class="fa fa-clock-o"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="bootstrap-timepicker">
                        <div class="form-group">
                            <label>Jam Selesai</label>
                            <div class="input-group">
                              <input type="text" class="form-control timepicker" id="end_time" name="end_time">
                              <div class="input-group-addon">
                                <i class="fa fa-clock-o"></i>
                              </div>
                            </div>
                          </div>
                        </div>

                        <button type="submit" class="btn btn-primary">Ajukan</button>
                        <a href="{{url("time-sheet")}}" class="btn btn-danger">Batal</a> 
                </div>
            </form>
            </div> --}}

            <form role="form" name="formdata" method="post" enctype="multipart/form-data" action="{{url("time-sheet/store")}}">
            @csrf
            <div class="row">
              <div class="col-xs-12 col-xl-10 col-lg-10">
                  <input type="hidden" id="divisi_id" name="divisi_id" value="{{$karyawan->divisi_id}}">
                  <div class="form-group">
                    <label for="jenis_barang">Cost Account</label>
                    <select name="cost_account_id" type="text" class="form-control select2" id="cost_account_id"  style="width: 100%;" onchange="showfield(this.options[this.selectedIndex].value)" required>
                        <option selected disabled>-- Pilih Cost Account --</option>
                        @foreach($cost_account as $ca)
                            <option value="{{ $ca->id }}">{{ $ca->nama }}</option>
                        @endforeach
                    </select>
                    <span class="help-block" >{{ $errors->first('cost_account_id') }} </span>
                </div>
                <div id="div1"></div>
                <div id="div2"></div>
              </div>
            </div>
            <div class="row">
                  <div class="col-xs-12 col-xl-5 col-lg-5">
                    <div class="form-group">
                        <label for="start_time">Jam Mulai</label>
                        <select name="start_time" type="text" class="form-control select2" id="start_time"  style="width: 100%;" required>
                            <option selected disabled>-- Pilih jam mulai --</option>
                            @foreach($timework as $tw)
                                <option value="{{ $tw->start_time }}">{{ date('H:i', strtotime($tw->start_time)) }} </option>
                            @endforeach
                        </select>
                        <span class="help-block" >{{ $errors->first('start_time') }} </span>
                    </div>
                  </div>
                  <div class="col-xs-12 col-xl-5 col-lg-5">
                    <div class="form-group">
                      <label for="end_time">Jam Selesai</label>
                      <select name="end_time" type="text" class="form-control select2" id="end_time"  style="width: 100%;" required>
                          <option selected disabled>-- Pilih jam selesai --</option>
                          @foreach($timework as $tw)
                              <option value="{{ $tw->end_time }}"> {{ date('H:i', strtotime($tw->end_time)) }} </option>
                          @endforeach
                      </select>
                      <span class="help-block" >{{ $errors->first('end_time') }} </span>
                  </div>
                </div>

            </div>
            <div class="row">
              <div class="col-xs-12 col-xl-12 col-lg-12">
                <button type="submit" class="btn btn-primary">Ajukan</button>
                <a href="{{url("time-sheet")}}" class="btn btn-danger">Batal</a> 
              </div>
            </div>
            </form>

          </div>
        </div>
      </div>
      </div>
      </section>
     
    @endsection
    @push('script')
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/js/select2.min.js"></script>
    <script src="{{ asset('AdminLTE-2.3.11/plugins/timepicker/bootstrap-timepicker.min.js') }}"></script>
    <link rel="stylesheet" href="{{ asset('AdminLTE-2.3.11/plugins/timepicker/bootstrap-timepicker.min.css')}}">
    {{-- <script src="https://cdn.tiny.cloud/1/j1ivozfjaqqnyz4pafn8n5mj5cij6xhty9nnn4vvbdms3v1f/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script> --}}
    <script src="{{asset('js/tinymce.min.js')}}" referrerpolicy="origin"></script>
    <script type="text/javascript" >
    // function reset(){
    //     $('.select2').val(null).trigger('change');
    // }
   
    $('.select2').select2();

    $(".timepicker").timepicker({
      showInputs: false,
      showMeridian: false
    });
    
    function showfield(name){
        if(name == 1 ){
            document.getElementById("div1").innerHTML='<div class="form-group">'+        
                    '<label>Tipe Pekerjaan</label>'+
                    '<select type="text" id="type" name="type" class="form-control select2" style="width: 100%;" required>'+
                    '<option selected disabled>-- Pilih Tipe Pekerjaan --</option>'+
                        '@foreach($work_type as $wt)<option value="{{ $wt->id }}">{{ $wt->nama }}</option>@endforeach'+
                    '</select><span class="help-block" >{{ $errors->first("type") }} </span></div>'+
                    '<div class="form-group">'+        
                '<label>Deskripsi Pekerjaan</label>'+
                '<textarea class="form-control my-editor" placeholder="Masukkan Deskripsi Pekerjaan" name="desc_for_ho" id="desc_for_ho"></textarea>'+
            '</div>'+
                    '<div class="form-group">'+
                      '<label>Tanggal Kerja</label>'+
                      '<div class="input-group date pickWeek">'+
                          '<span class="input-group-addon">'+
                              '<span class="glyphicon glyphicon-calendar"></span>'+
                          '</span>'+
                        '<input type="text" class="form-control" id="tanggal_kerja" name="tanggal_kerja" readonly value="{{ date("Y-m-d", strtotime(Carbon::now())) }}"/>'+
                      '</div>'+
                      '<span class="help-block" >{{ $errors->first("tanggal_kerja") }} </span>'+
                  '</div>';
                  $(function () {        
                  $('.pickWeek').datepicker({
                      locale: 'pt-br',
                      format: "yyyy-mm-dd",
                      autoclose: true,
                      sideBySide: true,
                      daysOfWeekDisabled: [0,7],
                      todayBtn: "linked",
                      todayHighlight : true,
                      // multidate:true,
                      startDate:moment().startOf('week').toDate(),
                      endDate:moment().endOf('week').toDate()
                  });
                  $('.select2').select2();
              });
               var editor_config = {
                  path_absolute : "/",
                  selector: "textarea.my-editor",
                  entity_encoding : "raw",
                  plugins: [
                  "advlist lists",
                  ],
                  toolbar: "bold italic | alignleft alignjustify | bullist numlist | outdent indent",
                  relative_urls: false,
                  menubar:false,

                  };
        
                tinymce.init(editor_config);
        }
        else if(name == 2){
            document.getElementById("div1").innerHTML='<div class="form-group">'+        
                '<label>Nama Proposal</label>'+
                '<select name="proposal_id" type="text" class="form-control select2" id="proposal_id" style="width: 100%;" onchange="getProposal(this.options[this.selectedIndex].value)" required>'+
                    '<option value = "0"> Marketing </option>'+
                    '<option selected disabled>-- Pilih Proposal --</option>'+
                        '@foreach($proposal as $p)<option value="{{ $p->id }}">{{ $p->nama }}</option>@endforeach'+
                '</select></div>'+
                '<div id="div-desc">'+
                '<div id="div2">';
        }
        else if(name == 3){
            document.getElementById("div1").innerHTML='<div class= "form-group">'+
            '<label>Role/Project</label>'+
            '<select name="project_id" type="text" class="form-control select2" id="project_id" style="width:100%" onchange="getDeskripsi(this.options[this.selectedIndex].value)" required>'+
            '<option selected disabled> Pilih Project </option>'+
            // '<option value = "1"> Marketing </option>'+
            // '<option disabled>-- Project --</option>'+
                '@foreach($project as $p)<option value="{{$p->id}}">{{ $p->nama }}</option>@endforeach'+
            '</select>'+
            '</div>'+
            '<div class="form-group">'+
            '<div id="div2"></div>'+
            '</div>';
            $(function () {    
                    $('.select2').select2();  
            });
        }
        else {
            document.getElementById("div1").innerHTML='';
        }
    }

    function getDeskripsi(val){
      if(val == 1){
          document.getElementById('div2').innerHTML ='<div class="form-group">'+        
                '<label>Deskripsi Pekerjaan</label>'+
                '<textarea class="form-control my-editor" placeholder="Masukkan Deskripsi Pekerjaan" name="desc_for_project" id="desc_for_project"></textarea>'+
            '</div>'+
            '<div class="form-group">'+
                '<label>Tanggal Kerja</label>'+
                '<div class="input-group date pickWeek">'+
                    '<span class="input-group-addon">'+
                        '<span class="glyphicon glyphicon-calendar"></span>'+
                    '</span>'+
                  '<input type="text" class="form-control" id="tanggal_kerja" name="tanggal_kerja" readonly value="{{ date("Y-m-d", strtotime(Carbon::now())) }}"/>'+
                '</div>'+
            '</div>';
            $(function () {    
                    // $('.select2').select2();    
                    $('.pickWeek').datepicker({
                        locale: 'pt-br',
                        format: "yyyy-mm-dd",
                        autoclose: true,
                        sideBySide: true,
                        // daysOfWeekDisabled: [0,6],
                        todayBtn: "linked",
                        todayHighlight : true,
                        // multidate:true,
                        startDate:moment().startOf('week').toDate(),
                        endDate:moment().endOf('week').toDate()
                    });
              });
                
                var editor_config = {
                  path_absolute : "/",
                  selector: "textarea.my-editor",
                  entity_encoding : "raw",
                  plugins: [
                  "advlist lists",
                  ],
                  toolbar: "bold italic | alignleft alignjustify | bullist numlist | outdent indent",
                  relative_urls: false,
                  menubar:false,

                  };
        
                tinymce.init(editor_config);
      }
      else{
          document.getElementById('div2').innerHTML ='<div class="form-group">'+
                    '<label>Pilih Resource</label>'+
                    '<select name="resource_id" type="text" class="form-control select2" id="resource_id" style="width: 100%;" required>'+
                      '<option selected disabled>-- Pilih Posisi --</option>'+
                      '@foreach($resource as $p)<option value="{{ $p->id }}">{{ $p->nama_posisi }}</option>@endforeach'+
                    '</select>'+
                    '</div>'+
                    '<div class="form-group">'+        
                    '<label>Deskripsi Pekerjaan</label>'+
                    '<textarea class="form-control my-editor" placeholder="Masukkan Deskripsi Pekerjaan" name="desc_for_project" id="desc_for_project"></textarea>'+
                    '</div>'+
                    '<div class="form-group">'+
                    '<label>Tanggal Kerja</label>'+
                    '<div class="input-group date pickWeek">'+
                        '<span class="input-group-addon">'+
                            '<span class="glyphicon glyphicon-calendar"></span>'+
                        '</span>'+
                      '<input type="text" class="form-control" id="tanggal_kerja" name="tanggal_kerja" readonly value="{{ date("Y-m-d", strtotime(Carbon::now())) }}"/>'+
                    '</div>'+
                '</div>';
                $(function () {    
                    $('.select2').select2();    
                    $('.pickWeek').datepicker({
                        locale: 'pt-br',
                        format: "yyyy-mm-dd",
                        autoclose: true,
                        sideBySide: true,
                        // daysOfWeekDisabled: [0,6],
                        todayBtn: "linked",
                        todayHighlight : true,
                        // multidate:true,
                        startDate:moment().startOf('week').toDate(),
                        endDate:moment().endOf('week').toDate()
                    });
              });

              var editor_config = {
              path_absolute : "/",
              selector: "textarea.my-editor",
              entity_encoding : "raw",
              plugins: [
              "advlist lists",
              ],
              toolbar: "bold italic | alignleft alignjustify | bullist numlist | outdent indent",
              relative_urls: false,
              menubar:false,

              };
    
            tinymce.init(editor_config);
        }
      }


    function getProposal(val){
        if(val == 0){
        // document.getElementById("div2").style.display = "none";
        // document.getElementById("div-desc").style.display = "block";
        document.getElementById("div2").innerHTML='<div class="form-group">'+
                                '<label>Deskripsi Pekerjaan</label>'+
                                '<textarea class="form-control my-editor" placeholder="Masukkan Deskripsi Pekerjaan" name="deskripsi_pekerjaan" id="deskripsi_pekerjaan"></textarea>'+
                                '</div>'+
                                '<div class="form-group">'+
                                    '<label>Tanggal Kerja</label>'+
                                    '<div class="input-group date pickWeek">'+
                                        '<span class="input-group-addon">'+
                                            '<span class="glyphicon glyphicon-calendar"></span>'+
                                        '</span>'+
                                      '<input type="text" class="form-control" id="tanggal_kerja" name="tanggal_kerja" readonly value="{{ date("Y-m-d", strtotime(Carbon::now()))}}"/>'+
                                    '</div>'+
                                '<div class="form-group">'+
                                '<input type="hidden" class="form-control" name="resource_id" id="resource_id" value="0" style="width: 100%;">'+
                                '</select>'+
                                '</div>'+
                                '</div>';
            $(function () {        
                  $('.pickWeek').datepicker({
                      locale: 'pt-br',
                      format: "yyyy-mm-dd",
                      autoclose: true,
                      sideBySide: true,
                      // daysOfWeekDisabled: [0,6],
                      todayBtn: "linked",
                      todayHighlight : true,
                      // multidate:true,
                      startDate:moment().startOf('week').toDate(),
                      endDate:moment().endOf('week').toDate()
                  });
              });
            var editor_config = {
                  path_absolute : "/",
                  selector: "textarea.my-editor",
                  entity_encoding : "raw",
                  plugins: [
                  "advlist lists",
                  ],
                  toolbar: "bold italic | alignleft alignjustify | bullist numlist | outdent indent",
                  relative_urls: false,
                  menubar:false,

              };

          tinymce.init(editor_config);
      }
      
      else{
        var proposal_id = $("#proposal_id").val();
        console.log("data proposal>>", proposal_id);

        if(proposal_id == -1){
            alert('Pilih Proposal dahulu!');
        }
        else{
            $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
             });
            $.ajax({
                type: "POST",
                url: "{{url('get-proposal/show')}}",
                data:{"proposal_id" : proposal_id},
                success: function(data){
                    data.forEach(myFunction);
                    function myFunction(item){
                    var loc = item.lokasi_id;

                    // var res = Array.from(item['resource_id'].split(','), Number);
                    // console.log("explode>>>", res);
                    
                    document.getElementById("div2").style.display = "block";
                    document.getElementById("div2").innerHTML='<div class="form-group">'+        
                                '<label>Lokasi</label>'+
                                '<input type="text" class="form-control" id="lokasi_id" name="lokasi_id" value="'+loc+'" readonly>'+
                                '</div>'+

                                '<div class="form-group">'+
                                '<label>Pilih Resource</label>'+
                                '<select name="resource_id" type="text" class="form-control select2" id="resource_id" style="width: 100%;" required>'+
                                '<option selected disabled>-- Pilih Posisi --</option>'+
                                '@foreach($resource as $p)<option value="{{ $p->id }}">{{ $p->nama_posisi }}</option>@endforeach'+
                                '</select>'+
                                '</div>'+

                                '<div class="form-group">'+
                                '<label>Deskripsi Pekerjaan</label>'+
                                '<textarea class="form-control my-editor" placeholder="Masukkan Deskripsi Pekerjaan" name="deskripsi_pekerjaan" id="deskripsi_pekerjaan"></textarea>'+
                                '</div>'+
                                
                                '<div class="form-group">'+
                                    '<label>Tanggal Kerja</label>'+
                                    '<div class="input-group date pickWeek">'+
                                        '<span class="input-group-addon">'+
                                            '<span class="glyphicon glyphicon-calendar"></span>'+
                                        '</span>'+
                                      '<input type="text" class="form-control" id="tanggal_kerja" name="tanggal_kerja" readonly value="{{ date("Y-m-d", strtotime(Carbon::now()))}}"/>'+
                                    '</div>'+
                                '</div>';

                                $(function () {   
                                    $('.select2').select2();
                                    $('.pickWeek').datepicker({
                                        locale: 'pt-br',
                                        format: "yyyy-mm-dd",
                                        autoclose: true,
                                        sideBySide: true,
                                        // daysOfWeekDisabled: [0,6],
                                        todayBtn: "linked",
                                        todayHighlight : true,
                                        // multidate:true,
                                        startDate:moment().startOf('week').toDate(),
                                        endDate:moment().endOf('week').toDate()
                                    });
                                });
                                 
                            console.log('datas>>>', item);
                            }
                                var editor_config = {
                                      path_absolute : "/",
                                      selector: "textarea.my-editor",
                                      entity_encoding : "raw",
                                      plugins: [
                                      "advlist lists",
                                      ],
                                      toolbar: "bold italic | alignleft alignjustify | bullist numlist | outdent indent",
                                          relative_urls: false,
                                          menubar:false,

                                      };
        
                            tinymce.init(editor_config);
                    }
                });
            }
}
    }


    </script>
    @endpush

