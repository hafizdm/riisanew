<?php
    use App\Resource;
    use App\Proposal;
?>
@extends('templates.header')

@section('content')

<section class="content">
    <div class="row">
        <div class="col-xs-12 col-xl-8 col-lg-8">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title fonts"><b>Edit Time Sheet</b></h3>
                </div>
                <br>
                <div class="box-body">
                    <div class="row">
                        <div class="col-lg-12 col-xs-12 col-xl-12">
                            @if(session()->get('success'))
                                <div class="alert alert-success alert-dismissible fade in"> {{ session()->get('success') }}
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                </div>
                            @endif
                        </div>    
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-xs-12 col-xl-12">
                        <form role="form" name="formdata" method="post" action="{{route('update-timesheet', $edit_timesheet->id)}}">
                            @method('PATCH') 
                            @csrf
                        <div class="row">
                            <div class="col-lg-12 col-xs-12 col-xl-12">
                               
                                    <div class="form-group">
                                        <label>Tanggal Kerja</label>
                                        <input type="text" class="form-control" value="{{ $edit_timesheet->tanggal_kerja}}" id="tanggal_kerja" name="tanggal_kerja" readonly>
                                    </div>
                                @if($edit_timesheet->cost_account_id == 1)
                                    <div class="form-group">
                                        <label>Cost Account</label>
                                        <input type="text" class="form-control" value="{{ $edit_timesheet->cost_account_id == 1 ? "General/Head Office" : "" }}" readonly>
                                        <input type="hidden" class="form-control" id="cost_account_id" name="cost_account_id" value="{{ $edit_timesheet->cost_account_id}}">
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Tipe Pekerjaan</label>
                                        <select class="form-control select2" name="working_type_id" id="working_type_id" style="width: 100%;" required> 
                                            <option selected disabled >--Pilih--</option>
                                            @foreach($work_type as $rs)
                                                <option {{$edit_timesheet->working_type_id == $rs->id ? 'selected' : ''}} value="{{$rs->id}}">{{$rs->nama}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Deskripsi Pekerjaan</label>
                                        <textarea class="form-control my-editor" id="desc_for_ho" name="desc_for_ho">{{$edit_timesheet->desc_for_ho}}</textarea>
                                    </div>

                                    <div class="form-group">
                                        <label>Jam Mulai</label>
                                        <div class="input-group">
                                        <input type="text" class="form-control timepicker"  id="start_time" name="start_time" value="{{ $edit_timesheet->start_time != '' ? date('H:i', strtotime($edit_timesheet->start_time)) : ''}}" readonly>
                                        <div class="input-group-addon">
                                            <i class="fa fa-clock-o"></i>
                                          </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label>Jam Selesai</label>
                                        <div class="input-group">
                                            <input type="text" class="form-control timepicker" id="end_time" name="end_time" value="{{ $edit_timesheet->end_time != '' ? date('H:i', strtotime($edit_timesheet->end_time)) : ''}}" readonly>
                                            <div class="input-group-addon">
                                              <i class="fa fa-clock-o"></i>
                                            </div>
                                          </div>
                                    </div>
                                    
                                @elseif($edit_timesheet->cost_account_id == 2)
                                    <div class="form-group">
                                        <label>Cost Account</label>
                                        <input type="text" class="form-control" value="{{ $edit_timesheet->cost_account_id == 2 ? "Proposal" : "" }}" readonly>
                                        <input type="hidden" class="form-control" id="cost_account_id" name="cost_account_id" value="{{ $edit_timesheet->cost_account_id}}">
                                    </div>

                                    <div class="form-group">
                                        <label>Nama Proposal</label>
                                        <input type="text" class="form-control" value="{{ $edit_timesheet->proposal_id == 0 ? 'Marketing' :  $edit_timesheet->getProposal->nama}}" readonly>
                                    </div>
                                    
                                    @if($edit_timesheet->proposal_id == 0)
                                    
                                    @else
                                        <div class="form-group">
                                            <label>Lokasi</label>
                                            <input type="text" class="form-control" value="{{ $edit_timesheet->getProposal->getLokasi->lokasi}}" readonly>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Resource</label>
                                            <select class="form-control select2" name="resource_id" id="resource_id" style="width: 100%;" required> 
                                                <option selected disabled >--Pilih--</option>
    
                                                @foreach($resource as $rs)
                                                    <option {{$edit_timesheet->resource_id == $rs->id ? 'selected' : ''}} value="{{$rs->id}}">{{$rs->nama_posisi}}</option>
                                                @endforeach
    
                                            </select>
                                    </div>
                                    
                                    @endif
                                    
                                    <div class="form-group">
                                        <label>Jam Mulai</label>
                                        <div class="input-group">
                                        <input type="text" class="form-control timepicker" id="start_time" name="start_time" value="{{ $edit_timesheet->start_time != '' ? date('H:i', strtotime($edit_timesheet->start_time)) : ''}}" readonly>
                                        <div class="input-group-addon">
                                            <i class="fa fa-clock-o"></i>
                                        </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label>Jam Selesai</label>
                                        <div class="input-group">
                                            <input type="text" class="form-control timepicker" id="end_time" name="end_time" value="{{ $edit_timesheet->end_time != '' ? date('H:i', strtotime($edit_timesheet->end_time)) : ''}}" readonly>
                                            <div class="input-group-addon">
                                            <i class="fa fa-clock-o"></i>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Deskripsi Pekerjaan</label>
                                        <textarea class="form-control my-editor" id="desc_for_proposal" name="desc_for_proposal">{{$edit_timesheet->desc_for_proposal}}</textarea>
                                    </div>
                                @else
                                    <div class="form-group">
                                        <label>Cost Account</label>
                                        <input type="text" class="form-control" value="{{ $edit_timesheet->cost_account_id == 3 ? "Project" : "" }}" readonly>
                                        <input type="hidden" class="form-control" id="cost_account_id" name="cost_account_id" value="{{ $edit_timesheet->cost_account_id}}">
                                    </div>

                                    <div class="form-group">
                                        <label>Role</label>
                                        <select class="form-control select2" name="project_id" id="project_id" style="width: 100%;" required> 
                                            @if($edit_timesheet->project_id == 1)
                                                <option selected value="1">Marketing</option>
                                                <option disabled> -- Project -- </option>
                                                @foreach($project as $p)
                                                    <option value="{{$p->id}}">{{$p->nama}}</option>
                                                @endforeach
                                            @else
                                            <option disabled>-- Project --</option>
                                                @foreach($project as $p)
                                                    <option {{$edit_timesheet->project_id == $p->id ? 'selected' : ''}} value="{{$p->id}}">{{$p->nama}}</option>
                                                @endforeach
                                                <option disabled>-- Lainnya --</option>
                                                <option value="1">Marketing</option>
                                            @endif
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label>Jam Mulai</label>
                                        <div class="input-group">
                                        <input type="text" class="form-control timepicker"  id="start_time" name="start_time" value="{{ $edit_timesheet->start_time != '' ? date('H:i', strtotime($edit_timesheet->start_time)) : ''}}" readonly>
                                        <div class="input-group-addon">
                                            <i class="fa fa-clock-o"></i>
                                        </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label>Jam Selesai</label>
                                        <div class="input-group">
                                            <input type="text" class="form-control timepicker" id="end_time" name="end_time" value="{{ $edit_timesheet->end_time != '' ? date('H:i', strtotime($edit_timesheet->end_time)) : ''}}" readonly>
                                            <div class="input-group-addon">
                                            <i class="fa fa-clock-o"></i>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Deskripsi Pekerjaan</label>
                                        <textarea class="form-control my-editor" id="desc_for_project" name="desc_for_project">{{$edit_timesheet->desc_for_project}}</textarea>
                                    </div>
                                @endif
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                    <a href="{{url("time-sheet")}}" class="btn btn-danger">Batal</a>
                        </div>
                        </div>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>  
    @endsection
    @push('script')
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/js/select2.min.js"></script>
        <script src="{{ asset('AdminLTE-2.3.11/plugins/timepicker/bootstrap-timepicker.min.js') }}"></script>
        <link rel="stylesheet" href="{{ asset('AdminLTE-2.3.11/plugins/timepicker/bootstrap-timepicker.min.css')}}">
        <script src="{{asset('js/tinymce.min.js')}}" referrerpolicy="origin"></script>
        <script type="text/javascript">
            $('.select2').select2()

            $(".timepicker").timepicker({
                showInputs: false,
                showMeridian: false
            });

            var editor_config = {
                  path_absolute : "/",
                  selector: "textarea.my-editor",
                  entity_encoding : "raw",
                  plugins: [
                  "advlist lists",
                  ],
                  toolbar: "bold italic | alignleft alignjustify | bullist numlist | outdent indent",
                  relative_urls: false,
                  menubar:false,

                  };
        
                tinymce.init(editor_config);
            
        </script>
    @endpush
    
