<?php
foreach($hari_libur  as $libur){
      $liburs = $libur->tanggal;
  }
?>

@extends('templates.header')

@section('content')
<!-- Content Header (Page header) -->
<section class="content-header">
    <span class="fonts header-style">
      <b>Time Sheet Management</b>
        {{-- <small>it all starts here</small>  --}}
    </span>
    <ol class="breadcrumb">
      <li><a href="{{url('')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active"><a href="{{url('time-sheet')}}"> Time Sheet Management </a></li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
<!-- filter field -->
{{-- <div class="row">
        <div class="col-md-6">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Filter</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"></i>
                </button>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <form action="#" name="formFilter" id="formFilter">
            <div class="box-body">
                        <div class="form-group">
                            <label for="filter_nik" class="col-sm-4 control-label">Status Pengajuan</label>
                            <div class="col-sm-8">
                              <select class="form-control select2" name="status_pengajuan" id="status_pengajuan" style="width: 100%;">
                                <option selected></option>
                                  <option value="0" >PENDING</option>
                                  <option value="1" >APPROVED</option>
                                  <option value="2" >REJECTED</option>
                              </select>
                              <span class="help-block"></span>
                            </div>  
                            <span class="help-block"></span>
                        </div>
                </div>
              </form>
            <div class="box-footer">
                    <button type="button" class="btn btn-default " id="resetFilter" name="resetFilter" ><span class="fa fa-refresh"></span> Reset</button>
                    <button type="button" class="btn btn-primary pull-right" id="btnFilter" name="btnFilter" ><span class="fa fa-filter"></span> Filter</button>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
    </div>  --}}
    <!-- end of filter field -->
    <!-- Default box -->
    <div class="box">
      {{-- <div class="box-header with-border">
        <h3 class="box-title">Select2</h3>

        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
          <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
        </div>
      </div> --}}

        <div class="box-body">
            @if(session()->get('success'))
            <div class="alert alert-success alert-dismissible fade in"> {{ session()->get('success') }}
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            </div>
            @elseif(session()->get('failed'))
            <div class="alert alert-danger alert-dismissible fade in"> 
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <h4><i class="icon fa fa-ban"></i> Pemberitahuan !</h4>
              {{ session()->get('failed') }}
            </div>
            @endif

            <div class="col-md-12">
              <div style="margin-bottom: 20px">
                <a href="{{url('time-sheet/create')}}" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Tambah Time Sheet </a>
              </div>
              
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="active"><a href="#Senin" data-toggle="tab">Senin</a></li>
                  <li><a href="#Selasa" data-toggle="tab">Selasa</a></li>
                  <li><a href="#Rabu" data-toggle="tab">Rabu</a></li>
                  <li><a href="#Kamis" data-toggle="tab">Kamis</a></li>
                  <li><a href="#Jumat" data-toggle="tab">Jumat</a></li>
                  <li><a href="#HariLibur" data-toggle="tab">Hari Libur</a></li>
                  <li><a href="#all" data-toggle="tab">Data Keseluruhan</a></li>
                </ul>
                <div class="tab-content">
{{-- SENIN --}}
        <div class="active tab-pane" id="Senin">
          <div class="table-responsive">
            <table id="senin" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        {{-- <th width="5%">No.</th> --}}
                        <th>Tanggal Kerja</th>
                        <th>Cost Account</th>
                        <th>Jam Mulai</th>
                        <th>Jam Selesai</th>
                        <th>Total Jam</th>
                        <th>Role</th>
                        <th>Deskripsi Pekerjaan</th>
                        <th>Status</th>
                        <th style="width:35px;">Aksi</th>
                        
                    </tr>
                </thead>
                <tbody>
                  @foreach($time_sheet as $k => $d)
                    @if(date('l', strtotime($d->tanggal_kerja)) == "Monday" && $d->tanggal_kerja != $liburs)
                      <tr>
                        
                        <td>{{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}
                         @if($d->getCostAccount->id == 1)
                            <td>General/Head Office</td>
                         @elseif($d->getCostAccount->id == 2)
                            @if($d->proposal_id == 0)
                              <td>Marketing</td>
                            @else
                              <td>{{$d->getProposal->nama}}</td>
                            @endif
                         @else
                            <td>Project ({{$d->getLoc->nama}})</td>
                        @endif

                        <td>{{ date('H:i', strtotime($d->start_time)) }}</td>
                        <td>{{ date('H:i', strtotime($d->end_time)) }}</td>
                        <td>{{$d->man_hours}} jam</td>

                       @if($d->cost_account_id == 1)
                            <td>{{$d->getDiv->nama}}</td>
                            <td>{{$d->workingType->nama}}
                            <br><b>Detail:</b>
                              <br>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_ho)) !!}
                            </td>
                        @elseif($d->cost_account_id == 2)
                            @if($d->proposal_id == 0)
                              <td>Marketing</td>
                            @else
                              <td>{{$d->getRes->nama_posisi}}</td>
                            @endif
                              <td>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_proposal)) !!}</td>
                        @else
                          
                            <td>{{$d->getRes->nama_posisi}}</td>
                         
                            <td>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_project)) !!}</td>
                        @endif
                        
                        @if($d->status == 0)
                          <td><span class="label label-warning">Menunggu</span></td>
                        @elseif($d->status == 1)
                          <td><span class="label label-success">Disetujui</span></td>
                        @else
                            <td><span class="label label-danger">Ditolak</span></td>
                        @endif
                        @if($d->status == 0)
                          <td>
                            <center>
                              <a href="{{route('edit-timesheet',$d->id)}}" class="btn btn-default btn-xs" style="color: dodgerblue;"><span class="glyphicon glyphicon-pencil"></span></a>
                              <button class='btn btn-xs btn-default delete' data-id="{{$d->id}}" style="color: dodgerblue;"><span class='glyphicon glyphicon-trash'></span></button>
                            </center>
                            </td>
                        @else
                          <td>
                            <center>
                              <a href="#" class="btn btn-default btn-xs" style="color: dodgerblue;"><span class="glyphicon glyphicon-pencil"></span></a>
                              <button class='btn btn-xs btn-default' data-id="#" style="color: dodgerblue;"><span class='glyphicon glyphicon-trash'></span></button>
                            </center>
                            </td>
                        @endif
                      </tr>
                      @endif
                      @endforeach
                  </tbody>
            </table>
            </div>
            </div>
{{-- SELASA --}}
            <div class="tab-pane" id="Selasa">
              {{-- <div style="margin-bottom: 20px">
                <a href="{{url('time-sheet/create')}}" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Tambah Time Sheet </a>
              </div> --}}
              <div class="table-responsive">
                <table id="selasa" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            {{-- <th width="5%">No.</th> --}}
                            <th>Tanggal Kerja</th>
                            <th>Cost Account</th>
                            <th>Jam Mulai</th>
                            <th>Jam Selesai</th>
                            <th>Total Jam</th>
                            <th>Role</th>
                            <th>Deskripsi Pekerjaan</th>
                            <th>Status</th>
                            <th style="width:35px;">Aksi</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                      @foreach($time_sheet as $k => $d)
                        @if(date('l', strtotime($d->tanggal_kerja)) == "Tuesday" && $d->tanggal_kerja != $liburs)
                          <tr>
                            <td>{{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}
                            @if($d->getCostAccount->id == 1)
                                <td>General/Head Office</td>
                            @elseif($d->getCostAccount->id == 2)
                              @if($d->proposal_id == 0)
                                <td>Marketing</td>
                              @else
                                  <td>{{$d->getProposal->nama}}</td>
                              @endif
                            @else
                                 <td>Project ({{$d->getLoc->nama}})</td>
                            @endif
                            
                            <td>{{ date('H:i', strtotime($d->start_time)) }}</td>
                            <td>{{ date('H:i', strtotime($d->end_time)) }}</td>
                            <td>{{$d->man_hours}} jam</td>

                            @if($d->cost_account_id == 1)
                                <td>{{$d->getDiv->nama}}</td>
                                <td>{{$d->workingType->nama}}
                                <br><b>Detail:</b>
                                <br>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_ho)) !!}
                                </td>
                            @elseif($d->cost_account_id == 2)
                              @if($d->proposal_id == 0)
                                <td>Marketing</td>
                              @else
                                <td>{{$d->getRes->nama_posisi}}</td>
                              @endif
                                <td>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_proposal)) !!}</td>
                            @else
                                <td>{{$d->getRes->nama_posisi}}</td>
                              <td>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_project)) !!}</td>
                            @endif
                            
                            @if($d->status == 0)
                              <td><span class="label label-warning">Menunggu</span></td>
                            @elseif($d->status == 1)
                              <td><span class="label label-success">Disetujui</span></td>
                            @else
                            <td><span class="label label-danger">Ditolak</span></td>
                            @endif
                            @if($d->status == 0)
                            <td>
                              <center>
                                <a href="{{route('edit-timesheet',$d->id)}}" class="btn btn-default btn-xs" style="color: dodgerblue;"><span class="glyphicon glyphicon-pencil"></span></a>
                                <button class='btn btn-xs btn-default delete' data-id="{{$d->id}}" style="color: dodgerblue;"><span class='glyphicon glyphicon-trash'></span></button>
                              </center>
                            </td>
                          @else
                            <td>
                              <center>
                                <a href="#" class="btn btn-default btn-xs" style="color: dodgerblue;"><span class="glyphicon glyphicon-pencil"></span></a>
                                <button class='btn btn-xs btn-default' data-id="#" style="color: dodgerblue;"><span class='glyphicon glyphicon-trash'></span></button>
                              </center>
                              </td>
                          @endif
                          </tr>
                          @endif
                          @endforeach
                      </tbody>
                </table>
                </div>
            </div>
{{-- RABU --}}
            <div class="tab-pane" id="Rabu">
              {{-- <div style="margin-bottom: 20px">
                <a href="{{url('time-sheet/create')}}" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Tambah Time Sheet </a>
              </div> --}}
              <div class="table-responsive">
                <table id="rabu" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            {{-- <th width="5%">No.</th> --}}
                            <th>Tanggal Kerja</th>
                            <th>Cost Account</th>
                            <th>Jam Mulai</th>
                            <th>Jam Selesai</th>
                            <th>Total Jam</th>
                            <th>Role</th>
                            <th>Deskripsi Pekerjaan</th>
                            <th>Status</th>
                            <th style="width:35px;">Aksi</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                      @foreach($time_sheet as $k => $d)
                        @if(date('l', strtotime($d->tanggal_kerja)) == "Wednesday" && $d->tanggal_kerja != $liburs)
                          <tr>
                           
                            <td>{{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}
                            
                            @if($d->getCostAccount->id == 1)
                                <td>General/Head Office</td>
                            @elseif($d->getCostAccount->id == 2)
                              @if($d->proposal_id == 0)
                                <td>Marketing</td>
                              @else
                                  <td>{{$d->getProposal->nama}}</td>
                              @endif
                            @else
                                 <td>Project ({{$d->getLoc->nama}})</td>
                            @endif
                            
                            <td>{{ date('H:i', strtotime($d->start_time)) }}</td>
                            <td>{{ date('H:i', strtotime($d->end_time)) }}</td>
                            <td>{{$d->man_hours}} jam</td>

                            @if($d->cost_account_id == 1)
                              <td>{{$d->getDiv->nama}}</td>
                              <td>{{$d->workingType->nama}}
                              <br><b>Detail:</b>
                              <br>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_ho)) !!}
                              </td>
                            @elseif($d->cost_account_id == 2)
                            @if($d->proposal_id == 0)
                                <td>Marketing</td>
                              @else
                                  <td>{{$d->getRes->nama_posisi}}</td>
                              @endif
                             
                              <td>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_proposal)) !!}</td>
                            @else
                              
                                <td>{{$d->getRes->nama_posisi}}</td>
                              
                              <td>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_project)) !!}</td>
                            @endif
                            
                            @if($d->status == 0)
                              <td><span class="label label-warning">Menunggu</span></td>
                            @elseif($d->status == 1)
                              <td><span class="label label-success">Disetujui</span></td>
                            @else
                            <td><span class="label label-danger">Ditolak</span></td>
                            @endif

                            @if($d->status == 0)
                              <td>
                                <center>
                                  <a href="{{route('edit-timesheet',$d->id)}}" class="btn btn-default btn-xs" style="color: dodgerblue;"><span class="glyphicon glyphicon-pencil"></span></a>
                                  <button class='btn btn-xs btn-default delete' data-id="{{$d->id}}" style="color: dodgerblue;"><span class='glyphicon glyphicon-trash'></span></button>
                                </center>
                                </td>
                            @else
                              <td>
                                <center>
                                  <a href="#" class="btn btn-default btn-xs" style="color: dodgerblue;"><span class="glyphicon glyphicon-pencil"></span></a>
                                  <button class='btn btn-xs btn-default' data-id="#" style="color: dodgerblue;"><span class='glyphicon glyphicon-trash'></span></button>
                                </center>
                                </td>
                            @endif
                          </tr>
                          @endif
                          @endforeach
                      </tbody>
                </table>
                </div>
            </div>

{{-- KAMIS --}}
            <div class="tab-pane" id="Kamis">
              {{-- <div style="margin-bottom: 20px">
                <a href="{{url('time-sheet/create')}}" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Tambah Time Sheet </a>
              </div> --}}
              <div class="table-responsive">
                <table id="kamis" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>Tanggal Kerja</th>
                            <th>Cost Account</th>
                            <th>Jam Mulai</th>
                            <th>Jam Selesai</th>
                            <th>Total Jam</th>
                            <th>Role</th>
                            <th>Deskripsi Pekerjaan</th>
                            <th>Status</th>
                            <th style="width:35px;">Aksi</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                      @foreach($time_sheet as $k => $d)
                        @if(date('l', strtotime($d->tanggal_kerja)) == "Thursday" && $d->tanggal_kerja != $liburs)
                          <tr>
                            <td>{{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}

                            @if($d->getCostAccount->id == 1)
                                <td>General/Head Office</td>
                            @elseif($d->getCostAccount->id == 2)
                                @if($d->proposal_id == 0)
                                  <td>Marketing</td>
                                @else
                                  <td>{{$d->getProposal->nama}}</td>
                                @endif

                            @else
                                <td>Project ({{$d->getLoc->nama}})</td>
                            @endif

                            <td>{{ date('H:i', strtotime($d->start_time)) }}</td>
                            <td>{{ date('H:i', strtotime($d->end_time)) }}</td>
                            <td>{{$d->man_hours}} jam</td>

                            @if($d->cost_account_id == 1)
                              <td>{{$d->getDiv->nama}}</td>
                              <td>{{$d->workingType->nama}}
                              <br><b>Detail:</b>
                              <br>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_ho)) !!}
                              </td>
                            @elseif($d->cost_account_id == 2)
                              @if($d->proposal_id == 0)
                                <td>Marketing</td>
                              @else
                                  <td>{{$d->getRes->nama_posisi}}</td>
                              @endif
                              <td>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_proposal)) !!}</td>
                            @else
                                <td>{{$d->getRes->nama_posisi}}</td>
                                <td>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_project)) !!}</td>
                            @endif
                            
                            
                            @if($d->status == 0)
                              <td><span class="label label-warning">Menunggu</span></td>
                            @elseif($d->status == 1)
                              <td><span class="label label-success">Disetujui</span></td>
                            @else
                            <td><span class="label label-danger">Ditolak</span></td>
                            @endif
                            @if($d->status == 0)
                              <td>
                                <center>
                                  <a href="{{route('edit-timesheet',$d->id)}}" class="btn btn-default btn-xs" style="color: dodgerblue;"><span class="glyphicon glyphicon-pencil"></span></a>
                                  <button class='btn btn-xs btn-default delete' data-id="{{$d->id}}" style="color: dodgerblue;"><span class='glyphicon glyphicon-trash'></span></button>
                                </center>
                              </td>
                            @else
                              <td>
                                  <center>
                                    <a href="#" class="btn btn-default btn-xs" style="color: dodgerblue;"><span class="glyphicon glyphicon-pencil"></span></a>
                                    <button class='btn btn-xs btn-default' data-id="#" style="color: dodgerblue;"><span class='glyphicon glyphicon-trash'></span></button>
                                  </center>
                              </td>
                            @endif
                          </tr>
                          @endif
                          @endforeach
                      </tbody>
                </table>
                </div>
            </div>
{{-- JUMAT --}}
            <div class="tab-pane" id="Jumat">
          
              <div class="table-responsive">
                <table id="jumat" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            {{-- <th width="5%">No.</th> --}}
                            <th>Tanggal Kerja</th>
                            <th>Cost Account</th>
                            <th>Jam Mulai</th>
                            <th>Jam Selesai</th>
                            <th>Total Jam</th>
                            <th>Role</th>
                            <th>Deskripsi Pekerjaan</th>
                            <th>Status</th>
                            <th style="width:35px;">Aksi</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                      @foreach($time_sheet as $k => $d)
                        @if(date('l', strtotime($d->tanggal_kerja)) == "Friday" && $d->tanggal_kerja != $liburs)
                          <tr>
                            <td>{{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}
                            @if($d->getCostAccount->id == 1)
                              <td>General/Head Office</td>
                            @elseif($d->getCostAccount->id == 2)
                            @if($d->proposal_id == 0)
                                <td>Marketing</td>
                              @else
                                  <td>{{$d->getProposal->nama}}</td>
                              @endif
                            @else
                                <td>Project ({{$d->getLoc->nama}})</td>
                            @endif


                            <td>{{ date('H:i', strtotime($d->start_time)) }}</td>
                            <td>{{ date('H:i', strtotime($d->end_time)) }}</td>
                            <td>{{$d->man_hours}} jam</td>

                          @if($d->cost_account_id == 1)
                              <td>{{$d->getDiv->nama}}</td>
                              <td>{{$d->workingType->nama}}
                              <br><b>Detail:</b>
                              <br>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_ho)) !!}
                              </td>
                            @elseif($d->cost_account_id == 2)
                              @if($d->proposal_id == 0)
                                <td>Marketing</td>
                              @else
                                  <td>{{$d->getRes->nama_posisi}}</td>
                              @endif
                              <td>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_proposal)) !!}</td>
                            @else
                                <td>{{$d->getRes->nama_posisi}}</td>
                                <td>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_project)) !!}</td>
                            @endif
                            
                            
                            @if($d->status == 0)
                              <td><span class="label label-warning">Menunggu</span></td>
                            @elseif($d->status == 1)
                              <td><span class="label label-success">Disetujui</span></td>
                            @else
                            <td><span class="label label-danger">Ditolak</span></td>
                            @endif
                            
                            
                            @if($d->status == 0)
                              <td>
                                <center>
                                  <a href="{{route('edit-timesheet',$d->id)}}" class="btn btn-default btn-xs" style="color: dodgerblue;"><span class="glyphicon glyphicon-pencil"></span></a>
                                  <button class='btn btn-xs btn-default delete' data-id="{{$d->id}}" style="color: dodgerblue;"><span class='glyphicon glyphicon-trash'></span></button>
                                </center>
                                </td>
                            @else
                              <td>
                                <center>
                                  <a href="#" class="btn btn-default btn-xs" style="color: dodgerblue;"><span class="glyphicon glyphicon-pencil"></span></a>
                                  <button class='btn btn-xs btn-default' data-id="#" style="color: dodgerblue;"><span class='glyphicon glyphicon-trash'></span></button>
                                </center>
                              </td>
                            @endif
                          </tr>
                          @endif
                          @endforeach
                      </tbody>
                </table>
                </div>
            </div>

            {{-- HARI LIBUR --}}
            <div class="tab-pane" id="HariLibur">
              {{-- <div style="margin-bottom: 20px">
                <a href="{{url('time-sheet/create')}}" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Tambah Time Sheet </a>
              </div> --}}
              <div class="table-responsive">
                <table id="libur" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>Tanggal Kerja</th>
                            <th>Hari</th>
                            <th>Cost Account</th>
                            <th>Jam Mulai</th>
                            <th>Jam Selesai</th>
                            <th>Total Jam</th>
                            <th>Role</th>
                            <th>Deskripsi Pekerjaan</th>
                            <th>Status</th>
                            <th style="width:35px;">Aksi</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                     
                      @foreach($time_sheet as $k => $d)
                        @if(date('l', strtotime($d->tanggal_kerja)) == "Sunday" || date('l', strtotime($d->tanggal_kerja)) == "Saturday" || $d->tanggal_kerja == $liburs)
                          <tr>
                            {{-- <td>{{$loop->iteration}}</td> --}}
                            <td>{{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}
                            @if(date('l', strtotime($d->tanggal_kerja)) == "Sunday")
                                <td>Minggu</td>
                            @elseif(date('l', strtotime($d->tanggal_kerja)) == "Saturday")
                                <td>Sabtu</td>
                            @elseif($d->tanggal_kerja == $liburs)
                                <td>Libur Nasional/Cuti Bersama</td>
                            @endif
                            
                            @if($d->getCostAccount->id == 1)
                              <td>General/Head Office</td>
                            @elseif($d->getCostAccount->id == 2)
                              @if($d->proposal_id == 0)
                                <td>Marketing</td>
                              @else
                                  <td>{{$d->getProposal->nama}}</td>
                              @endif
                            @else
                                <td>Project ({{$d->getLoc->nama}})</td>
                            @endif

                            <td>{{ date('H:i', strtotime($d->start_time)) }}</td>
                            <td>{{ date('H:i', strtotime($d->end_time)) }}</td>
                            <td>{{$d->man_hours}} jam</td>

                            @if($d->cost_account_id == 1)
                              <td>{{$d->getDiv->nama}}</td>
                              <td>{{$d->workingType->nama}}
                              <br><b>Detail:</b>
                              <br>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_ho)) !!}
                              </td>
                            @elseif($d->cost_account_id == 2)
                              @if($d->proposal_id == 0)
                                <td>Marketing</td>
                              @else
                                  <td>{{$d->getRes->nama_posisi}}</td>
                              @endif
                              <td>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_proposal)) !!}</td>
                            @else
                                <td>{{$d->getRes->nama_posisi}}</td>
                                <td>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_project)) !!}</td>
                            @endif
                            
                            @if($d->status == 0)
                              <td><span class="label label-warning">Menunggu</span></td>
                            @elseif($d->status == 1)
                              <td><span class="label label-success">Disetujui</span></td>
                            @else
                            <td><span class="label label-danger">Ditolak</span></td>
                            @endif
                            @if($d->status == 0)
                              <td>
                                <center>
                                  <a href="{{route('edit-timesheet',$d->id)}}" class="btn btn-default btn-xs" style="color: dodgerblue;"><span class="glyphicon glyphicon-pencil"></span></a>
                                  <button class='btn btn-xs btn-default delete' data-id="{{$d->id}}" style="color: dodgerblue;"><span class='glyphicon glyphicon-trash'></span></button>
                                </center>
                              </td>
                             @else
                              <td>
                                <center>
                                  <a href="#" class="btn btn-default btn-xs" style="color: dodgerblue;"><span class="glyphicon glyphicon-pencil"></span></a>
                                  <button class='btn btn-xs btn-default' data-id="#" style="color: dodgerblue;"><span class='glyphicon glyphicon-trash'></span></button>
                                </center>
                              </td>
                              @endif
                          </tr>
                          @endif
                          @endforeach
                      </tbody>
                </table>
                </div>
            </div>

            {{-- ALL --}}
            <div class="tab-pane" id="all">
              <div class="table-responsive">
                <table id="all-data" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th width="5%">No.</th>
                            {{-- <th>Tanggal</th> --}}
                            <th>Tanggal Kerja</th>
                            <th>Cost Account</th>
                            <th>Jam Mulai</th>
                            <th>Jam Selesai</th>
                            <th>Total Jam</th>
                            <th>Role</th>
                            <th>Deskripsi Pekerjaan</th>
                            <th>Status</th>
                            <th style="width:35px;">Aksi</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                      @foreach($time_sheet as $k => $d)
                          <tr>
                            <td>{{$loop->iteration}}</td>
                            {{-- <td>{{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td> --}}
                            
                              @if(date('l', strtotime($d->tanggal_kerja)) == "Sunday" && $d->tanggal_kerja != $liburs)
                                <td>Minggu, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td>
                              @elseif(date('l', strtotime($d->tanggal_kerja)) == "Monday" && $d->tanggal_kerja != $liburs)
                                <td>Senin, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td>
                              @elseif(date('l', strtotime($d->tanggal_kerja)) == "Tuesday" && $d->tanggal_kerja != $liburs)
                                <td>Selasa, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td>
                              @elseif(date('l', strtotime($d->tanggal_kerja)) == "Wednesday" && $d->tanggal_kerja != $liburs)
                                <td>Rabu, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td>
                              @elseif(date('l', strtotime($d->tanggal_kerja)) == "Thursday" && $d->tanggal_kerja != $liburs)
                                <td>Kamis, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td>
                              @elseif(date('l', strtotime($d->tanggal_kerja)) == "Friday" && $d->tanggal_kerja != $liburs)
                                <td>Jumat, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td>
                              @elseif(date('l', strtotime($d->tanggal_kerja)) == "Saturday" && $d->tanggal_kerja != $liburs)
                                  <td>Sabtu, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td>
                              @else
                                  <td>Libur Nasional/Cuti Bersama, {{ date('d-M-Y', strtotime($d->tanggal_kerja)) }}</td>
                              @endif

                            @if($d->getCostAccount->id == 1)
                                <td>General/Head Office</td>
                            @elseif($d->getCostAccount->id == 2)
                              @if($d->proposal_id == 0)
                                <td>Marketing</td>
                              @else
                                  <td>{{$d->getProposal->nama}}</td>
                              @endif
                            @else
                                  <td>Project ({{$d->getLoc->nama}})</td>
                            @endif


                            <td>{{ date('H:i', strtotime($d->start_time)) }}</td>
                            <td>{{ date('H:i', strtotime($d->end_time)) }}</td>
                            <td>{{$d->man_hours}} jam</td>
                            
                            @if($d->cost_account_id == 1)
                                <td>{{$d->getDiv->nama}}</td>
                                <td>{{$d->workingType->nama}}
                                <br><b>Detail:</b>
                                <br>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_ho)) !!}
                                </td>
                            @elseif($d->cost_account_id == 2)
                                @if($d->proposal_id == 0)
                                  <td>Marketing</td>
                                @else
                                  <td>{{$d->getRes->nama_posisi}}</td>
                                @endif
                                  <td>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_proposal)) !!}</td>
                            @else
                                  <td>{{$d->getRes->nama_posisi}}</td>
                                  <td>{!! preg_replace("/<p>/", '-'.' ' , ($d->desc_for_project)) !!}</td>
                            @endif
                            
                            
                            @if($d->status == 0)
                              <td><span class="label label-warning">Menunggu</span></td>
                            @elseif($d->status == 1)
                              <td><span class="label label-success">Disetujui</span></td>
                            @else
                            <td><span class="label label-danger">Ditolak</span></td>
                            @endif
                            @if($d->status == 0)
                              <td>
                                <center>
                                  <a href="{{route('edit-timesheet',$d->id)}}" class="btn btn-default btn-xs" style="color: dodgerblue;"><span class="glyphicon glyphicon-pencil"></span></a>
                                  <button class='btn btn-xs btn-default delete' data-id="{{$d->id}}" style="color: dodgerblue;"><span class='glyphicon glyphicon-trash'></span></button>
                                </center>
                              </td>
                            @else
                            <td>
                              <center>
                                <a href="#" class="btn btn-default btn-xs" style="color: dodgerblue;"><span class="glyphicon glyphicon-pencil"></span></a>
                                <button class='btn btn-xs btn-default' data-id="#" style="color: dodgerblue;"><span class='glyphicon glyphicon-trash'></span></button>
                              <center>
                              </td>
                            @endif
                          </tr>
                          @endforeach
                      </tbody>
                </table>
                </div>
            </div>

                </div>
              </div>
            </div>

        </div>
        <!-- /.box-body -->
        <div class="box-footer"></div>
        <!-- /.box-footer-->
    </div>
    <!-- /.box -->

</section>
<!-- /.content -->
<!-- modal konfirmasi -->

{{-- <div class="modal fade" id="modal-konfirmasi" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title" id="myModalLabel">Konfirmasi</h4>
            </div>
            <div class="modal-body" id="konfirmasi-body"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger" data-id="" data-loading-text="<i class='fa fa-circle-o-notch fa-spin'></i> Deleting..." id="confirm-delete">Delete</button>
            </div>
        </div>
    </div>
</div> --}}

@include('timesheet.user.confirm')

<!-- end of modal konfirmasi -->
@endsection
@push('script')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

<script>

$(function(){
   var mainTable = $('#senin').DataTable();
   var tb_selasa = $("#selasa").DataTable();
   var tb_rabu = $("#rabu").DataTable();
   var tb_kamis = $("#kamis").DataTable();
   var tb_jumat = $("#jumat").DataTable();
   var tb_libur = $("#libur").DataTable();
   var tb_all = $("#all-data").DataTable();

   var selectedRow;
   var selectedRow1;
   var selectedRow2;
   var selectedRow3;
   var selectedRow4;
   var selectedRow5;
   var selectedRow6;

  $('#senin').on('click', '.delete', function (e) {
    e.preventDefault();
    selectedRow = mainTable.row( $(this).parents('tr') );

    $("#modal-konfirmasi").modal('show');

    $("#modal-konfirmasi").find("#confirm-delete").data("id", $(this).data('id'));
    $("#konfirmasi-body").text("Hapus TimeSheet?");
  });

  $('#confirm-delete').click(function(){
      var deleteButton = $(this);
      var id           = deleteButton.data("id");

      deleteButton.button('loading');

      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax(
      {
        url: "time-sheet/"+id,
        type: 'POST',
        dataType: "JSON",
        data: {
          // _method:"DELETE"
          // "id": id
        },
        success: function (response)
        {
          deleteButton.button('reset');

          selectedRow.remove().draw();

          $("#modal-konfirmasi").modal('hide');

          Swal.fire({
            title: response.success,
            // text: response.success,
            type: 'success',
            confirmButtonText: 'Close',
            confirmButtonColor: '#AAA',
            onClose: function(){
               
            }
          })
        },
        error: function(xhr) {
          console.log(xhr.responseText);
        }
      });
  });

  $('#selasa').on('click', '.delete', function (e) {
    e.preventDefault();
    selectedRow1 = tb_selasa.row( $(this).parents('tr') );

    $("#modal-konfirmasi2").modal('show');

    $("#modal-konfirmasi2").find("#confirm-delete2").data("id", $(this).data('id'));
    $("#konfirmasi-body2").text("Hapus TimeSheet?");
  });

  $('#confirm-delete2').click(function(){
      var deleteButton = $(this);
      var id           = deleteButton.data("id");

      deleteButton.button('loading');

      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax(
      {
        url: "time-sheet/"+id,
        type: 'POST',
        dataType: "JSON",
        data: {
          // _method:"DELETE"
          // "id": id
        },
        success: function (response)
        {
          deleteButton.button('reset');

          selectedRow1.remove().draw();

          $("#modal-konfirmasi2").modal('hide');

          Swal.fire({
            title: response.success,
            // text: response.success,
            type: 'success',
            confirmButtonText: 'Close',
            confirmButtonColor: '#AAA',
            onClose: function(){
               
            }
          })
        },
        error: function(xhr) {
          console.log(xhr.responseText);
        }
      });
  });

  $('#rabu').on('click', '.delete', function (e) {
    e.preventDefault();
    selectedRow2 = tb_rabu.row( $(this).parents('tr') );

    $("#modal-konfirmasi3").modal('show');

    $("#modal-konfirmasi3").find("#confirm-delete3").data("id", $(this).data('id'));
    $("#konfirmasi-body3").text("Hapus TimeSheet?");
  });

  $('#confirm-delete3').click(function(){
      var deleteButton = $(this);
      var id        = deleteButton.data("id");

      deleteButton.button('loading');

      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax(
      {
        url: "time-sheet/"+id,
        type: 'POST',
        dataType: "JSON",
        data: {
          // _method:"DELETE"
          // "id": id
        },
        success: function (response)
        {
          deleteButton.button('reset');

          selectedRow2.remove().draw();

          $("#modal-konfirmasi3").modal('hide');

          Swal.fire({
            title: response.success,
            // text: response.success,
            type: 'success',
            confirmButtonText: 'Close',
            confirmButtonColor: '#AAA',
            onClose: function(){
               
            }
          })
        },
        error: function(xhr) {
          console.log(xhr.responseText);
        }
      });
  });

  $('#kamis').on('click', '.delete', function (e) {
    e.preventDefault();
    selectedRow3 = tb_kamis.row( $(this).parents('tr') );

    $("#modal-konfirmasi4").modal('show');

    $("#modal-konfirmasi4").find("#confirm-delete4").data("id", $(this).data('id'));
    $("#konfirmasi-body").text("Hapus TimeSheet?");
  });

  $('#confirm-delete4').click(function(){
      var deleteButton = $(this);
      var id           = deleteButton.data("id");

      deleteButton.button('loading');

      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax(
      {
        url: "time-sheet/"+id,
        type: 'POST',
        dataType: "JSON",
        data: {
          // _method:"DELETE"
          // "id": id
        },
        success: function (response)
        {
          deleteButton.button('reset');

          selectedRow3.remove().draw();

          $("#modal-konfirmasi4").modal('hide');

          Swal.fire({
            title: response.success,
            // text: response.success,
            type: 'success',
            confirmButtonText: 'Close',
            confirmButtonColor: '#AAA',
            onClose: function(){
               
            }
          })
        },
        error: function(xhr) {
          console.log(xhr.responseText);
        }
      });
  });

  $('#jumat').on('click', '.delete', function (e) {
    e.preventDefault();
    selectedRow4 = tb_jumat.row( $(this).parents('tr') );

    $("#modal-konfirmasi5").modal('show');

    $("#modal-konfirmasi5").find("#confirm-delete5").data("id", $(this).data('id'));
    $("#konfirmasi-body5").text("Hapus TimeSheet?");
  });

  $('#confirm-delete5').click(function(){
      var deleteButton = $(this);
      var id           = deleteButton.data("id");

      deleteButton.button('loading');

      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax(
      {
        url: "time-sheet/"+id,
        type: 'POST',
        dataType: "JSON",
        data: {
          // _method:"DELETE"
          // "id": id
        },
        success: function (response)
        {
          deleteButton.button('reset');

          selectedRow4.remove().draw();

          $("#modal-konfirmasi5").modal('hide');

          Swal.fire({
            title: response.success,
            // text: response.success,
            type: 'success',
            confirmButtonText: 'Close',
            confirmButtonColor: '#AAA',
            onClose: function(){
               
            }
          })
        },
        error: function(xhr) {
          console.log(xhr.responseText);
        }
      });
  });


  $('#libur').on('click', '.delete', function (e) {
    e.preventDefault();
    selectedRow5 = tb_libur.row( $(this).parents('tr') );

    $("#modal-konfirmasi6").modal('show');

    $("#modal-konfirmasi6").find("#confirm-delete6").data("id", $(this).data('id'));
    $("#konfirmasi-body6").text("Hapus TimeSheet?");
  });

  $('#confirm-delete6').click(function(){
      var deleteButton = $(this);
      var id           = deleteButton.data("id");

      deleteButton.button('loading');

      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax(
      {
        url: "time-sheet/"+id,
        type: 'POST',
        dataType: "JSON",
        data: {
          // _method:"DELETE"
          // "id": id
        },
        success: function (response)
        {
          deleteButton.button('reset');

          selectedRow5.remove().draw();

          $("#modal-konfirmasi6").modal('hide');

          Swal.fire({
            title: response.success,
            // text: response.success,
            type: 'success',
            confirmButtonText: 'Close',
            confirmButtonColor: '#AAA',
            onClose: function(){
               
            }
          })
        },
        error: function(xhr) {
          console.log(xhr.responseText);
        }
      });
  });

  $('#all-data').on('click', '.delete', function (e) {
    e.preventDefault();
    selectedRow6 = tb_all.row( $(this).parents('tr') );

    $("#modal-konfirmasi7").modal('show');

    $("#modal-konfirmasi7").find("#confirm-delete7").data("id", $(this).data('id'));
    $("#konfirmasi-body7").text("Hapus TimeSheet?");
  });

  $('#confirm-delete7').click(function(){
      var deleteButton = $(this);
      var id           = deleteButton.data("id");

      deleteButton.button('loading');

      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax(
      {
        url: "time-sheet/"+id,
        type: 'POST',
        dataType: "JSON",
        data: {
          // _method:"DELETE"
          // "id": id
        },
        success: function (response)
        {
          deleteButton.button('reset');

          selectedRow6.remove().draw();

          $("#modal-konfirmasi7").modal('hide');

          Swal.fire({
            title: response.success,
            // text: response.success,
            type: 'success',
            confirmButtonText: 'Close',
            confirmButtonColor: '#AAA',
            onClose: function(){
               
            }
          })
        },
        error: function(xhr) {
          console.log(xhr.responseText);
        }
      });
  });

});
</script>
@endpush 


