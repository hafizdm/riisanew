<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::auth();

Route::get('login-user', function () {
    return view('login-form');
});

Route::group(['middleware' => 'auth'], function () {

	Route::group(['middleware' => 'auth.input'], function () {
		Route::get('', 'HomeController@index');
});
	
// Role Karyawan Request
Route::group(['namespace' => 'Request', 'middleware' => 'auth.karyawan'], function () {

	// Request Pembelian
	Route::get('request','ReqTransactionController@index');
	Route::get('request/create','ReqTransactionController@create');

	Route::post('request/store','ReqTransactionController@store');
	Route::post('request/{id}','ReqTransactionController@destroy')->name('deletedrequest');
	Route::get('request/{id}','ReqTransactionController@edit')->name('editrequest');
	Route::patch('request/{id}','ReqTransactionController@update')->name('updaterequest');
	Route::get('listRequest','ReqTransactionController@listPengajuan');
	Route::post('requestpembelian/{id}','ReqTransactionController@destroy');

	// Request Barang Keluar
	Route::get('request-barang-keluar','ReqTransactionController@indexRequestPengeluaran');
	Route::get('request-barang-keluar/{id}','ReqTransactionController@editRequestPengeluaran')->name('editrequest-barang-keluar');
	Route::patch('request-barang-keluar/{id}','ReqTransactionController@updateRequestPengeluaran')->name('updaterequest-barang-keluar');

	// reset password
	Route::get('ganti-password/{id}','resetPasswordController@edit')->name('editpassword');
	Route::patch('ganti-password/{id}','resetPasswordController@update')->name('updatepassword');
	// Route::post('request/chained', 'ReqTransactionController@chained_dropdown')->name('chained_dropdown');

	// Dropdown Barang 
	Route::post('get-barang/store','ReqTransactionController@getBarangList');
	
});


// Route::group(['namespace' => 'Staff', 'middleware' => 'auth.karyawan'], function () {
Route::group(['namespace' => 'Staff'], function () {
	// Data Diri
	Route::get('ubah-data-diri/{id}','DatadiriController@editProfil')->name('edit-profil');
	Route::patch('ubah-data-diri/{id}','DatadiriController@updateProfil')->name('update-profil');

	// Pengalaman 
	Route::get('pengalaman','DatadiriController@indexPengalaman');
	Route::get('pengalaman/create','DatadiriController@createPengalaman');
	Route::post('pengalaman/store','DatadiriController@storePengalaman');
	Route::get('pengalaman/{id}','DatadiriController@editPengalaman')->name('edit-pengalaman');
	Route::patch('pengalaman/{id}','DatadiriController@updatePengalaman')->name('update-pengalaman');
	Route::delete('pengalaman/{id}','DatadiriController@destroyPengalaman');

	// Pendidikan 
	Route::get('pendidikan','DatadiriController@indexPendidikan');
	Route::get('pendidikan/create','DatadiriController@createPendidikan');
	Route::post('pendidikan/store','DatadiriController@storePendidikan');
	Route::get('pendidikan/{id}','DatadiriController@editPendidikan')->name('edit-pendidikan');
	Route::patch('pendidikan/{id}','DatadiriController@updatePendidikan')->name('update-pendidikan');
	Route::delete('pendidikan/{id}','DatadiriController@destroyPendidikan');

	// Upload File
	Route::get('upload-file','DatadiriController@indexUploadFile');

	// upload cv
	Route::get('upload-cv/create','DatadiriController@createFileCV');
	Route::post('upload-cv/store','DatadiriController@storeFileCV');
	Route::get('upload-cv/{id}','DatadiriController@editFileCV')->name('edit-cv');
	Route::patch('upload-cv/{id}','DatadiriController@updateFileCV')->name('update-cv');

	// upload ijazah
	Route::get('upload-ijazah/create','DatadiriController@createFileIjazah');
	Route::post('upload-ijazah/store','DatadiriController@storeFileIjazah');
	Route::get('upload-ijazah/{id}','DatadiriController@editFileIjazah')->name('edit-ijazah');
	Route::patch('upload-ijazah/{id}','DatadiriController@updateFileIjazah')->name('update-ijazah');

	// upload sertifikat
	Route::get('upload-sertifikat/create','DatadiriController@createFileSertifikat');
	Route::post('upload-sertifikat/store','DatadiriController@storeFileSertifikat');
	Route::get('upload-sertifikat/{id}','DatadiriController@editFileSertifikat')->name('edit-sertifikat');
	Route::patch('upload-sertifikat/{id}','DatadiriController@updateFileSertifikat')->name('update-sertifikat');
	Route::delete('upload-sertifikat/{id}','DatadiriController@destroySertifikat');
	
	// Time Sheet
	Route::get('time-sheet','TimeSheetController@index');
	Route::get('time-sheet/create','TimeSheetController@create');
	Route::post('time-sheet/store','TimeSheetController@store');
	Route::get('time-sheet/{id}','TimeSheetController@edit')->name('edit-timesheet');
	Route::patch('time-sheet/{id}','TimeSheetController@update')->name('update-timesheet');
	Route::post('time-sheet/{id}','TimeSheetController@destroy');
	Route::post('get-proposal/show','TimeSheetController@getProposalList');
	
});

// Manager
Route::group(['namespace' => 'HighLevel', 'middleware' => 'auth.manager'], function () {

	// Manager HO - Request
// 	Route::get('approvalManager','ApprovalControler@approvalManager');
// 	Route::get('approvalManager/{id}','ApprovalControler@editApprovalManager')->name('editapprovalmanager');
// 	Route::patch('approvalManager/{id}','ApprovalControler@updateApprovalManager')->name('updateapprovalmanager');
	
	// Manager Proyek - Request
	    Route::get('approvalManager','ApprovalControler@approvalManager');
		Route::get('approvalManagerProjek/{id}','ApprovalControler@editApprovalManagerProjek')->name('editapprovalmanagerprojek');
		Route::patch('approvalManagerProjek/{id}','ApprovalControler@updateApprovalManagerProjek')->name('updateapprovalmanagerprojek');
// 	Route::get('approvalManagerProjek/{id}','ApprovalControler@editApprovalManagerProjek')->name('editapprovalmanagerprojek');
// 	Route::patch('approvalManagerProjek/{id}','ApprovalControler@updateApprovalManagerProjek')->name('updateapprovalmanagerprojek');

	// Reset Password
	Route::get('ganti-password-manager/{id}','ApprovalControler@editPasswordManager')->name('editpassword-manager');
	Route::patch('ganti-password-manager/{id}','ApprovalControler@updatePasswordManager')->name('updatepassword-manager');
	
    // Purchased 
		Route::get('po-pm', 'ApprovalPurchaseController@indexApprovalPM');
		Route::get('po-pm-edit/{id}', 'ApprovalPurchaseController@editApprovalPM')->name('editapprovalpm-po');
		Route::patch('po-pm-update/{id}', 'ApprovalPurchaseController@updateApprovalPM')->name('updateapprovalpm-po');
});

// VP
Route::group(['namespace' => 'HighLevel', 'middleware' => 'auth.vp'], function () {
	// Request
	Route::get('approvalVP','ApprovalControler@approvalVP');
	Route::get('approvalVP/{id}','ApprovalControler@editApprovalVP')->name('editapprovalvp');
	Route::patch('approvalVP/{id}','ApprovalControler@updateApprovalVP')->name('updateapprovalvp');
    
    // Purchased 
		Route::get('po-vp', 'ApprovalPurchaseController@indexApprovalVP');
		Route::get('po-vp-edit/{id}', 'ApprovalPurchaseController@editApprovalVP')->name('editapprovalvp-po');
		Route::patch('po-vp-update/{id}', 'ApprovalPurchaseController@updateApprovalVP')->name('updateapprovalvp-po');
		
	// Reset Password
	Route::get('ganti-password-vp/{id}','ApprovalControler@editPasswordVP')->name('editpassword-vp');
	Route::patch('ganti-password-vp/{id}','ApprovalControler@updatePasswordVP')->name('updatepassword-vp');
});

// CEO
Route::group(['namespace' => 'HighLevel', 'middleware' => 'auth.ceo'], function () {
	// Request
// 	Route::get('approvalCEO','ApprovalControler@approvalCEO');
// 	Route::get('approvalCEO/{id}','ApprovalControler@editApprovalCEO')->name('editapprovalceo');
// 	Route::patch('approvalCEO/{id}','ApprovalControler@updateApprovalCEO')->name('updateapprovalceo');

	// Purchased 
// 	Route::get('po-CEO','ApprovalPurchaseController@ceo');
// 	Route::get('po-CEO/{id}','ApprovalPurchaseController@ceoEdit')->name('editapprovalceo-po');
// 	Route::patch('po-CEO-update/{id}','ApprovalPurchaseController@ceoUpdate')->name('updateapprovalceo-po');

	// Payment
	Route::get('payment-ceo','ApprovalPaymentController@paymentCEO');
	Route::get('payment-ceo/{id}','ApprovalPaymentController@paymentCEOEdit')->name('editapprovalceo-payment');
	Route::patch('payment-ceo/{id}','ApprovalPaymentController@paymentCEOUpdate')->name('updateapprovalceo-payment');

	// Reset Password
	Route::get('ganti-password-ceo/{id}','ApprovalControler@editPasswordCEO')->name('editpassword-ceo');
	Route::patch('ganti-password-ceo/{id}','ApprovalControler@updatePasswordCEO')->name('updatepassword-ceo');
});

// CO
Route::group(['namespace' => 'HighLevel', 'middleware' => 'auth.co'], function () {
	// Purchased
	Route::get('po','ApprovalPurchaseController@CostControl');
	Route::get('ApprovalCO/{id}','ApprovalPurchaseController@editApprovalCO')->name('editapprovalco-po');
	Route::patch('ApprovalCo/{id}','ApprovalPurchaseController@updateApprovalCO')->name('updateapprovalco-po');

	// Payment
	Route::get('payment-co','ApprovalPaymentController@paymentCO');
	Route::get('payment-co/{id}','ApprovalPaymentController@paymentCOEdit')->name('editapprovalco-payment');
	Route::patch('payment-co/{id}','ApprovalPaymentController@paymentCOUpdate')->name('updateapprovalco-payment');

	// Reset Password
	Route::get('ganti-password-co/{id}','ApprovalPurchaseController@editPasswordCO')->name('editpassword-co');
	Route::patch('ganti-password-co/{id}','ApprovalPurchaseController@updatePasswordCO')->name('updatepassword-co');
});

// CFO
Route::group(['namespace' => 'HighLevel', 'middleware' => 'auth.cfo'], function () {
// Purchased
// 	Route::get('po-cfo', 'ApprovalPurchaseController@cfo');
// 	Route::get('po-cfo-edit/{id}', 'ApprovalPurchaseController@cfoedit')->name('editapprovalcfo-po');
// 	Route::patch('po-cfo-update/{id}', 'ApprovalPurchaseController@cfoupdate')->name('updateapprovalcfo-po');

// Payment
	Route::get('payment-cfo','ApprovalPaymentController@paymentCFO');
	Route::get('payment-cfo/{id}','ApprovalPaymentController@paymentCFOEdit')->name('editapprovalcfo-payment');
	Route::patch('payment-cfo/{id}','ApprovalPaymentController@paymentCFOUpdate')->name('updateapprovalcfo-payment');

	// Reset Password
	Route::get('ganti-password-cfo/{id}','ApprovalPurchaseController@editPasswordCFO')->name('editpassword-cfo');
	Route::patch('ganti-password-cfo/{id}','ApprovalPurchaseController@updatePasswordCFO')->name('updatepassword-cfo');

});

// Admin
Route::group(['namespace' => 'Admin', 'middleware' => 'auth.admin'], function (){
	//Master Data Vendor
	Route::get('listVendor', 'VendorController@index');
	Route::get('vendor/create', 'VendorController@create');
	Route::post('vendor/store', 'VendorController@store');
	Route::post('vendor/{id}', 'VendorController@destroy')->name('deletedvendor');
	Route::get('vendor/edit/{id}', 'VendorController@edit')->name('editvendor');
	Route::patch('vendor/update/{id}', 'VendorController@update')->name('updatevendor');
	
	// Cetak PDF
// 	Route::get('karyawan/cetak_pdf', 'KaryawanController@cetak_pdf');
// 	Route::get('karyawan/cetak_excel', 'KaryawanController@cetak_excel');

	//Master Data Divisi
	Route::get('divisi','DivisiController@index');
	Route::get('divisi/create','DivisiController@create');
	Route::post('divisi/store','DivisiController@store');
	Route::get('divisi/store','DivisiController@store');
	Route::post('divisi/{id}','DivisiController@destroy');
	Route::get('divisi/edit{id}','DivisiController@edit')->name('editdivisi');
	Route::patch('divisi/update{id}','DivisiController@update')->name('updatedivisi');

	//Master Data Kategori Barang
	Route::get('kategoribarang','KategoriBarangController@index');
	Route::get('kategoribarang/create','KategoriBarangController@create');
	Route::post('kategoribarang/store','KategoriBarangController@store');
	Route::post('kategoribarang/{id}','KategoriBarangController@destroy');
	Route::get('kategoribarang/edit{id}','KategoriBarangController@edit')->name('editkategori');
	Route::patch('kategoribarang/update{id}','KategoriBarangController@update')->name('updatekategori');

	//Master Data Barang
	Route::get('barang','BarangController@index');
	Route::get('barang/create','BarangController@create');
	Route::post('barang/store','BarangController@store');
	Route::post('barang/{id_barang}','BarangController@destroy')->name('deletedbarang');
	Route::get('barang/edit{id_barang}','BarangController@edit')->name('editbarang');
	Route::patch('barang/update{id_barang}','BarangController@update')->name('updatebarang');

	//Master Data Proyek
	Route::get('proyek','ProyekController@index');
	Route::get('proyek/create','ProyekController@create');
	Route::post('proyek/store','ProyekController@store');
	Route::post('proyek/{id}','ProyekController@destroy')->name('deletedproyek');
	Route::get('proyek/edit{id}','ProyekController@edit')->name('editproyek');
	Route::patch('proyek/update{id}','ProyekController@update')->name('updateproyek');

	//Master Data Jabatan
	Route::get('jabatan', 'JabatanController@index');
	Route::get('jabatan/create','JabatanController@create');
	Route::post('jabatan/store','JabatanController@store');
	Route::post('jabatan/{id}','JabatanController@destroy')->name('deletedjabatan');
	Route::get('jabatan/edit{id}','JabatanController@edit')->name('editjabatan');
	Route::patch('jabatan/update{id}','JabatanController@update')->name('updatejabatan');

	
    //Master Resources
	Route::get('resource','ResourceController@index');
	Route::get('resource/create','ResourceController@create');
	Route::post('resource/store','ResourceController@store');
	Route::post('resource/{id}','ResourceController@destroy')->name('deletedresource');
	Route::get('resource/edit{id}','ResourceController@edit')->name('editresource');
	Route::patch('resource/update{id}','ResourceController@update')->name('updateresource');

	//Master Kategori Kerja
	Route::get('cost-account','CostaccountController@index');
	Route::get('cost-account/create','CostaccountController@create');
	Route::post('cost-account/store','CostaccountController@store');
	Route::post('cost-account/{id}','CostaccountController@destroy')->name('deleted');
	Route::get('cost-account/edit{id}','CostaccountController@edit')->name('editcostaccount');
	Route::patch('cost-account/update{id}','CostaccountController@update')->name('updatecostaccount');

	//Master General_working_type
	 Route::get('general-work','GeneralController@index');
	 Route::get('general-work/create','GeneralController@create');
	 Route::post('general-work/store','GeneralController@store');
	 Route::post('general-work/{id}','GeneralController@destroy');
	 Route::get('general-work/edit{id}','GeneralController@edit')->name('editgeneral');
	 Route::patch('general-work/update{id}','GeneralController@update')->name('updategeneral');
	 
	//List Inventory Asset
	// Route::get('inventory', 'InventoryController@listinventory');

	// // List Inventory Non Asset
	// Route::get('inventory-nonasset','InventoryController@listnonasset');

	// //list Inventory Jasa
	// Route::get('inventory-jasa','InventoryController@listjasa');

	// listRequest
	Route::get('list-procurement', 'listProcurementController@index');


	//Upload PO
	Route::get('listPO', 'POController@index');
	Route::get('listPO/edit{id}','POController@edit')->name('editbuktiPO');
	Route::patch('listPO/update{id}','POController@update')->name('updateBuktiPO');

	Route::resources([
		'users' => 'UserController',
	]);
	Route::resources([
		'user_role' => 'UserRoleController',
	]);

});

Route::group(['namespace' => 'Finance', 'middleware' => 'auth.finance'], function (){
		//Upload Invoice
		Route::get('list-invoice', 'InvoiceController@index');
		Route::get('list-invoice/edit{id}','InvoiceController@edit')->name('editbuktiinvoice');
		Route::patch('list-invoice/update{id}','InvoiceController@update')->name('updatebuktiinvoice');

		Route::get('ubah-status-paid', 'PaidController@index');
		Route::get('ubah-status-paid/edit{id}','PaidController@edit')->name('editpaid');
		Route::patch('ubah-status-paid/update{id}','PaidController@update')->name('updatepaid');

		// Reset Password
		Route::get('ganti-password-finance/{id}','ResetPasswordController@edit')->name('editpassword-finance');
		Route::patch('ganti-password-finance/{id}','ResetPasswordController@update')->name('updatepassword-finance');
	});

	Route::group(['namespace' => 'AssetManagement', 'middleware' => 'auth.asset.management'], function (){
		Route::get('list-approval-barang-keluar', 'AssetManagementController@index');
		Route::get('list-approval-barang-keluar/edit{id}','AssetManagementController@edit')->name('editapprovalbrg');
		Route::patch('list-approval-barang-keluar/update{id}','AssetManagementController@update')->name('updateapprovalbrg');

		// Reset Password
		Route::get('ganti-password-assetmanagement/{id}','ResetPasswordController@edit')->name('editpassword-assetmanagement');
		Route::patch('ganti-password-assetmanagement/{id}','ResetPasswordController@update')->name('updatepassword-assetmanagement');
	});
	
	
    Route::group(['namespace'=> 'HRD', 'middleware'=> 'auth.hr'], function(){
        
		//Master Data Karyawan
		Route::get('karyawan','KaryawanController@index');
		Route::get('karyawan/create','KaryawanController@create');
		Route::post('karyawan/store','KaryawanController@store');
		Route::get('karyawan/edit{id}','KaryawanController@edit')->name('editkaryawan');
		Route::post('karyawan/{nik}', 'KaryawanController@destroy')->name('deletedkaryawan');
		Route::patch('karyawan/update/{id}', 'KaryawanController@update')->name('updatekaryawan');
		Route::post('get-jabatan-divisi/store','KaryawanController@getJabatanDivisi');
		
        // Riwayat Kontrak Kerja 
        Route::get('hapus-kontrak/{id}', 'KaryawanController@destroyKontrak')->name('deletedkontrak');
		
        // History SPD
        Route::get('history-spd','SPDController@index');
        Route::get('karyawan/cetak_excel', 'KaryawanController@cetak_excel');
});


Route::group(['namespace'=> 'TimeSheet', 'middleware' => 'auth.vp'], function () {

	// TimeSheet Proposal
	Route::get('time-sheet-proposal','TimeSheetController@timesheetProposal');
	Route::get('time-sheet-proposal/create','TimeSheetController@createTimesheetProposal');
	Route::post('time-sheet-proposal/store','TimeSheetController@storeTimesheetProposal');
	Route::get('time-sheet-proposal/{id}','TimeSheetController@editTimesheetProposal')->name('edit-timesheet-proposal');
	Route::patch('time-sheet-proposal/{id}','TimeSheetController@updateTimesheetProposal')->name('update-timesheet-proposal');
	Route::delete('time-sheet-proposal/{id}','TimeSheetController@destroyTimesheetProposal');
	Route::get('detail-timesheet/{id}','TimeSheetController@detailTimeSheetProposal');

	// Approval Timesheet Proposal
	Route::get('approval-timesheet/{id}','TimeSheetController@ubahApprovalTimesheet')->name('edit-status-timesheet');
	Route::patch('approval-timesheet/{id}','TimeSheetController@updateApprovalTimesheet')->name('update-status-timesheet');

	// Open Close Proposal
	Route::get('close-proposal/{id}','TimeSheetController@editCloseProposal')->name('edit-close-proposal');
	Route::patch('close-proposal/{id}','TimeSheetController@updateCloseProposal')->name('update-close-proposal');

	// Edit Resource Proposal
	Route::get('resource-proposal/{id}','TimeSheetController@editResourceProposal')->name('edit-resource-proposal');
	Route::patch('resource-proposal/{id}','TimeSheetController@updateResourceProposal')->name('update-resource-proposal');

	// Approval Timesheet HO
	
	Route::get('persentase-timesheet','TimeSheetController@timesheetHO');
	Route::get('approval-timesheet-ho/{id}','TimeSheetController@ubahApprovalTimesheetHO')->name('edit-status-timesheet-ho');
	Route::patch('approval-timesheet-ho/{id}','TimeSheetController@updateApprovalTimesheetHO')->name('update-status-timesheet-ho');
	Route::get('all-timesheet/{id}','TimeSheetController@alltimesheet');
	Route::post('filters/{id}','TimeSheetController@filter')->name('filters-ho');
// 	Route::get('time-sheet-ho','TimeSheetController@timesheetHO');
// 	Route::get('approval-timesheet-ho/{id}','TimeSheetController@ubahApprovalTimesheetHO')->name('edit-status-timesheet-ho');
// 	Route::patch('approval-timesheet-ho/{id}','TimeSheetController@updateApprovalTimesheetHO')->name('update-status-timesheet-ho');
// 	Route::get('all-time-sheet/{id}','TimeSheetController@alltimesheet');
// 	Route::post('filter/{id}','TimeSheetController@filter')->name('filter-ho');

	// TIMESHEET PROJECT
	Route::get('timesheet-project','TimeSheetController@TimesheetProject');
	Route::get('timesheet-project/create','TimeSheetController@Create_Timesheet_project');
	Route::post('timesheet-project/store','TimeSheetController@storeTimesheetProject');
	Route::delete('timesheet-project/{id}','TimeSheetController@destroyTimesheetProject');
	Route::get('detail-timesheet-project/{id}','TimeSheetController@detailTimeSheetProject');

	// Edit Resource Project
	Route::get('resource-project/{id}','TimeSheetController@editResourceProject')->name('edit-resource-project');
	Route::patch('resource-project/{id}','TimeSheetController@updateResourceProject')->name('update-resource-project');

	// Open Close Project
	Route::get('open-close-project/{id}','TimeSheetController@editCloseProject')->name('edit-open-close-project');
	Route::patch('open-close-project/{id}','TimeSheetController@updateCloseProject')->name('update-open-close-project');

	// Approval Timesheet Project
	Route::get('approval-timesheet-project/{id}','TimeSheetController@editTimesheetPR')->name('edit-status-timesheet-project');
	Route::patch('approval-timesheet-project/{id}','TimeSheetController@updateTimesheetPR')->name('update-status-timesheet-project');
	
    // Approval for Marketing 
        Route::get('time-sheet-marketing','TimeSheetController@TimesheetMarketing');
    	Route::get('approval-timesheet-marketing/{id}','TimeSheetController@editTimesheetMarketing')->name('edit-status-timesheet-marketing');
	    Route::patch('approval-timesheet-marketing/{id}','TimeSheetController@updateTimesheetMarketing')->name('update-status-timesheet-marketing');
	    
    // Fitur Approve All Timesheet
// 	Route::post('approve-proposal', 'TimeSheetController@approvalAllProposal');
// 	Route::post('approve-project', 'TimeSheetController@approvalAllProject');
	Route::post('approve-ho', 'TimeSheetController@approvalAllHO');
});

Route::group(['namespace'=> 'TimeSheet', 'middleware'=> 'auth.ceo'], function(){
	
	Route::get('approval-timesheet-ceo','TimeSheetController@approvalTimesheetProposal');
	
	// Approval Timesheet Proposal by CEO
	Route::get('approval-timesheet-ceo/{id}','TimeSheetController@ubahApprovalTimesheetProposal')->name('edit-approval-proposal');
	Route::patch('approval-timesheet-ceo/{id}','TimeSheetController@updateApprovalTimesheetProposal')->name('update-approval-proposal');

	// Approval Timesheet Project by CEO 
	Route::get('approval-project-ceo/{id}','TimeSheetController@ubahApprovalTimesheetProject')->name('edit-approval-project');
	Route::patch('approval-project-ceo/{id}','TimeSheetController@updateApprovalTimesheetProject')->name('update-approval-project');
	
    // 	Approval Timesheet HO
// 	Route::get('approval-timesheet-ho/{id}','TimeSheetController@ubahApprovalTimesheetHO')->name('edit-status-timesheet-ho');
// 	Route::patch('approval-timesheet-ho/{id}','TimeSheetController@updateApprovalTimesheetHO')->name('update-status-timesheet-ho');
// 	Route::post('approve-all', 'TimeSheetControllerCEO@approvalAll');
	
	Route::get('all-time-sheet/{id}','TimeSheetControllerCEO@alltimesheet');
	Route::post('filter/{id}','TimeSheetControllerCEO@filter')->name('filter-ho');
});


    Route::group(['namespace' => 'SPD'], function (){
        
	// Pengajuan SPD to All Karyawan
		Route::get('pengajuan-spd','SPDController@index');
		Route::get('pengajuan-spd/create','SPDController@create');
		Route::post('pengajuan-spd/store','SPDController@store');
		Route::get('downloadpdf/{id}','SPDController@downloadpdf');
		Route::get('pengajuan-spd/{id}','SPDController@edit')->name('edit-spd');
		Route::patch('pengajuan-spd/{id}','SPDController@update')->name('update-spd');
		Route::post('pengajuan-spd/{id}','SPDController@destroy');
	});

});

