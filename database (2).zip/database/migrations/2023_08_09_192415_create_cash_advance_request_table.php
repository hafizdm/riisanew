<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCashAdvanceRequestTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cash_advance_request', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedBigInteger('karyawan_id')->index();
            $table->date('request_date');
            $table->string('remarks');
            $table->string('allocation');
            $table->string('reason')->nullable();
            $table->integer('balance_received');
            $table->string('item_file');            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cash_advance_request');
    }
}
