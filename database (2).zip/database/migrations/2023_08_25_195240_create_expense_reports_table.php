<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateExpenseReportsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('expense_reports', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedBigInteger('cash_advance_request_id')->index();
            $table->date('request_date');
            $table->integer('cash_out');
            $table->integer('total_expense');
            $table->string('file_invoice');            
            $table->string('file_upload')->nullable();   
            $table->unsignedInteger('status');         
            $table->timestamps();   
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('expense_reports');
    }
}
