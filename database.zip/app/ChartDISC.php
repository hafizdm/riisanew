<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChartDISC extends Model
{
    protected $table = 'chart_disc';
    protected $primaryKey = 'id';
}
