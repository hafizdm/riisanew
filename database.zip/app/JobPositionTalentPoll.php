<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JobPositionTalentPoll extends Model
{
    protected $table = 'job_position';
    protected $primaryKey = 'id';
}
