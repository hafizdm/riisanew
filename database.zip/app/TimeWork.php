<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TimeWork extends Model
{
    protected $table = 'time_work';
    protected $primaryKey = 'id';
}
