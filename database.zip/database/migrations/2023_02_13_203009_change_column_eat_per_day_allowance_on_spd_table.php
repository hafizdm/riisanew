<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ChangeColumnEatPerDayAllowanceOnSpdTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('spd', function (Blueprint $table) {
            $table->renameColumn('eat_per_day_domestic', 'eat_per_day');
            $table->renameColumn('allowance_per_day_domestic', 'allowance');
            $table->dropColumn(['eat_per_day_international', 'allowance_per_day_international']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
