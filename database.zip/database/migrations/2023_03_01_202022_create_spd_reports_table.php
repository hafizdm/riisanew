<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSpdReportsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('spd_reports', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedBigInteger('spd_id')->index();
            $table->string('upload_report')->nullable();
            $table->string('upload_file')->nullable();
            $table->unsignedInteger('status');
            $table->bigInteger('cash_out');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('spd_reports');
    }
}
