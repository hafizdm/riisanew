@extends('templates.header')

@section('content')
<section class="content">
    <span>tes</span>
</section>
@endsection
