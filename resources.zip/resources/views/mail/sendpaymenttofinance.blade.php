<h4>
    <span>Dear Finance Team,</span>
    <br>
    <span>PT. Rapid Infrastruktur Indonesia</span>
</h4>
<br>
<span>Pengajuan barang telah disetujui.</span>
<span>Silahkan Upload dokumen yang diperlukan untuk proses selanjutnya. Klik <a href="https://riisa.rapidinfrastruktur.com">link</a> ini untuk login ke sistem</span>
<br>
<span>Terima Kasih</span>
<br>
<br>
<span>RII-SA Administration Team</span>
